import numpy as np
import matplotlib.pyplot as plt
import os
from natsort import natsorted
from collections import defaultdict
from collections import Counter
import math

det1_data_int = []
det2_data_int = []
det3_data_int = []
det4_data_int = []
det5_data_int = []
det6_data_int = []
det7_data_int = []
det8_data_int = []
det9_data_int = []
det10_data_int = []

det8_ur = []

det1_wifi_int = []
det2_wifi_int = []
det3_wifi_int = []
det4_wifi_int = []
det5_wifi_int = []
det6_wifi_int = []
det7_wifi_int = []
det8_wifi_int = []
det9_wifi_int = []
det10_wifi_int = []

def ch_grouper(data): #Only risetimes
    '''
    This function splits the read data by channel number
    '''
    #Seperates data based on gps channel
    ch0_list = [tup for tup in data if tup[4]==0 and tup[2]==0]
    ch1_list = [tup for tup in data if tup[4]==1 and tup[2]==0]
    
    return ch0_list, ch1_list

def folder_reader(folder_path):
    global folder_files_list 
    folder_files_list = []     
    for filename in os.listdir(folder_path):
        if filename.startswith('gps_daq'):
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):  # make sure it's a file
                file_name = file_path.replace("\\", "/")
                folder_files_list.append(file_name)
    return natsorted(folder_files_list) #Correctly sorted them based on number

ur_list = []

def data_parser(file):
    print(file)
    #if file.startswith("gps_daq"):
    file_path = os.path.join(folder_path, file)

    all_data = []

    BH_list = []
    Veto_list = []
    det1_list = []
    det2_list = []
    det3_list = []
    det4_list = []
    det5_list = []
    det6_list = []
    det7_list = []
    det8_list = []
    det9_list = []
    det10_list = []

    det1_rate = []
    det2_rate = []
    det3_rate = []
    det4_rate = []
    det5_rate = []
    det6_rate = []
    det7_rate = []
    det8_rate = []
    det9_rate = []
    det10_rate = []

    with open(file_path, 'r') as f:

        next(f) 
        for line in f:

            parts = line.strip().split(';')
            #print(parts)
            try:
                values = tuple(int(p.strip()) for p in parts) #Converts all elements to ints for easier analysis

            except Exception as e:
                print("Error", e)
                continue

            if values[0] == 96:
                ur_list.append(values)
            if values[0] == 98:  

                if values[1]==112:
                    det1_rate.append(values)
                if values[1]==180:
                    det2_rate.append(values)
                if values[1]==172:
                    det3_rate.append(values)
                if values[1]==64:
                    det4_rate.append(values)
                if values[1]==232:
                    det5_rate.append(values)
                if values[1]==252:
                    det6_rate.append(values)
                if values[1]==224:
                    det7_rate.append(values)
                if values[1]==20:
                    det8_rate.append(values) 
                if values[1]==104:
                    det9_rate.append(values)
                if values[1]==164:
                    det10_rate.append(values)

            if values[0]==99 and values[6]!=0 and values[2]==0: #Real data
                if values[6]<604800000 and values[7]<1000000: #Ignore nonsense ms and ns timestamps
                    all_data.append(values)

                    if values[1]==48 and values[4]==0:
                        BH_list.append(values)
                    if values[1]==16:
                        Veto_list.append(values)
                    if values[1]==112:
                        det1_list.append(values)
                    if values[1]==180:
                        det2_list.append(values)
                    if values[1]==172:
                        det3_list.append(values)
                    if values[1]==64:
                        det4_list.append(values)
                    if values[1]==232:
                        det5_list.append(values)
                    if values[1]==252:
                        det6_list.append(values)
                    if values[1]==224:
                        det7_list.append(values)
                    if values[1]==20:
                        det8_list.append(values)   
                    if values[1]==104:
                        det9_list.append(values)
                    if values[1]==164:
                        det10_list.append(values)

    request_count = (len(BH_list)+len(Veto_list))
    request_rate = (len(BH_list)+len(Veto_list))/3600

     

    det1_ch0, det1_ch1 = ch_grouper(det1_list)
    det1_ch0_count = len(det1_ch0)
    print("a",(det1_ch0_count))
    det1_ch1_count = len(det1_ch1)
    det1_rate = np.array(det1_rate)
    if len(det1_rate)!=0:        
        det1_ch0_rate = np.mean(det1_rate[:,2])
        det1_ch1_rate = np.mean(det1_rate[:,4])
        det1_nulls = np.sum(det1_rate[:,6])
    else:
        det1_ch0_rate = 1000000
        det1_ch1_rate = 1000000
        det1_nulls = 0
    det1_ch0_unique_events_set = set(tup[8] for tup in det1_ch0)

    det1_ch1_unique_events_set = set(tup[8] for tup in det1_ch1)
    det1_ch0_unique_events = len(det1_ch0_unique_events_set)
    print("b", det1_ch0_unique_events)
    det1_ch1_unique_events = len(det1_ch1_unique_events_set)
    det1_ch_intersection = det1_ch0_unique_events_set & det1_ch1_unique_events_set
    det1_unique_count = len(set(tup[8] for tup in det1_list))
    det1_calc_rate = ((det1_ch0_rate+det1_ch1_rate) * request_rate * (2*10**-3))
    
    det2_ch0, det2_ch1 = ch_grouper(det2_list)
    det2_ch0_count = len(det2_ch0)
    det2_ch1_count = len(det2_ch1)
    det2_rate = np.array(det2_rate)
    if len(det2_rate)!=0:        
        det2_ch0_rate = np.mean(det2_rate[:,2])
        det2_ch1_rate = np.mean(det2_rate[:,4])
        det2_nulls = np.sum(det2_rate[:,6])
    else:
        det2_ch0_rate = 1000000
        det2_ch1_rate = 1000000
        det2_nulls = 0
    det2_ch0_unique_events_set = set(tup[8] for tup in det2_ch0)
    det2_ch1_unique_events_set = set(tup[8] for tup in det2_ch1)
    det2_ch0_unique_events = len(det2_ch0_unique_events_set)
    det2_ch1_unique_events = len(det2_ch1_unique_events_set)
    det2_ch_intersection = det2_ch0_unique_events_set & det2_ch1_unique_events_set
    det2_unique_count = len(set(tup[8] for tup in det2_list))
    det2_calc_rate = ((det2_ch0_rate+det2_ch1_rate) * request_rate * (2*10**-3))

    det3_ch0, det3_ch1 = ch_grouper(det3_list)
    det3_ch0_count = len(det3_ch0)
    det3_ch1_count = len(det3_ch1)
    det3_rate = np.array(det3_rate)
    if len(det3_rate)!=0:        
        det3_ch0_rate = np.mean(det3_rate[:,2])
        det3_ch1_rate = np.mean(det3_rate[:,4])
        det3_nulls = np.sum(det3_rate[:,6])
    else:
        det3_ch0_rate = 1000000
        det3_ch1_rate = 1000000
        det3_nulls = 0
    det3_ch0_unique_events_set = set(tup[8] for tup in det3_ch0)
    det3_ch1_unique_events_set = set(tup[8] for tup in det3_ch1)
    det3_ch0_unique_events = len(det3_ch0_unique_events_set)
    det3_ch1_unique_events = len(det3_ch1_unique_events_set)
    det3_ch_intersection = det3_ch0_unique_events_set & det3_ch1_unique_events_set
    det3_unique_count = len(set(tup[8] for tup in det3_list))
    det3_calc_rate = ((det3_ch0_rate+det3_ch1_rate) * request_rate * (2*10**-3))

    det4_ch0, det4_ch1 = ch_grouper(det4_list)
    det4_ch0_count = len(det4_ch0)
    det4_ch1_count = len(det4_ch1)
    det4_rate = np.array(det4_rate)
    if len(det4_rate)!=0:        
        det4_ch0_rate = np.mean(det4_rate[:,2])
        det4_ch1_rate = np.mean(det4_rate[:,4])
        det4_nulls = np.sum(det4_rate[:,6])
    else:
        det4_ch0_rate = 1000000
        det4_ch1_rate = 1000000
        det4_nulls = 0
    det4_ch0_unique_events_set = set(tup[8] for tup in det4_ch0)
    det4_ch1_unique_events_set = set(tup[8] for tup in det4_ch1)
    det4_ch0_unique_events = len(det4_ch0_unique_events_set)
    det4_ch1_unique_events = len(det4_ch1_unique_events_set)
    det4_ch_intersection = det4_ch0_unique_events_set & det4_ch1_unique_events_set
    det4_unique_count = len(set(tup[8] for tup in det4_list))
    det4_calc_rate = ((det4_ch0_rate+det4_ch1_rate) * request_rate * (2*10**-3))
    
    det5_ch0, det5_ch1 = ch_grouper(det5_list)
    det5_ch0_count = len(det5_ch0)
    det5_ch1_count = len(det5_ch1)
    det5_rate = np.array(det5_rate)
    if len(det5_rate)!=0:        
        det5_ch0_rate = np.mean(det5_rate[:,2])
        det5_ch1_rate = np.mean(det5_rate[:,4])
        det5_nulls = np.sum(det5_rate[:,6])
    else:
        det5_ch0_rate = 1000000
        det5_ch1_rate = 1000000
        det5_nulls = 0
    det5_ch0_unique_events_set = set(tup[8] for tup in det5_ch0)
    det5_ch1_unique_events_set = set(tup[8] for tup in det5_ch1)
    det5_ch0_unique_events = len(det5_ch0_unique_events_set)
    det5_ch1_unique_events = len(det5_ch1_unique_events_set)
    det5_ch_intersection = det5_ch0_unique_events_set & det5_ch1_unique_events_set
    det5_unique_count = len(set(tup[8] for tup in det5_list))
    det5_calc_rate = ((det5_ch0_rate+det5_ch1_rate) * request_rate * (2*10**-3))
    
    det6_ch0, det6_ch1 = ch_grouper(det6_list)
    det6_ch0_count = len(det6_ch0)
    det6_ch1_count = len(det6_ch1)
    det6_rate = np.array(det6_rate)
    if len(det6_rate)!=0:        
        det6_ch0_rate = np.mean(det6_rate[:,2])
        det6_ch1_rate = np.mean(det6_rate[:,4])
        det6_nulls = np.sum(det6_rate[:,6])
    else:
        det6_ch0_rate = 1000000
        det6_ch1_rate = 1000000
        det6_nulls = 0
    det6_ch0_unique_events_set = set(tup[8] for tup in det6_ch0)
    det6_ch1_unique_events_set = set(tup[8] for tup in det6_ch1)
    det6_ch0_unique_events = len(det6_ch0_unique_events_set)
    det6_ch1_unique_events = len(det6_ch1_unique_events_set)
    det6_ch_intersection = det6_ch0_unique_events_set & det6_ch1_unique_events_set
    det6_unique_count = len(set(tup[8] for tup in det6_list))
    det6_calc_rate = ((det6_ch0_rate+det6_ch1_rate) * request_rate * (2*10**-3))

    det7_ch0, det7_ch1 = ch_grouper(det7_list)
    det7_ch0_count = len(det7_ch0)
    det7_ch1_count = len(det7_ch1)
    det7_rate = np.array(det7_rate)
    if len(det7_rate)!=0:        
        det7_ch0_rate = np.mean(det7_rate[:,2])
        det7_ch1_rate = np.mean(det7_rate[:,4])
        det7_nulls = np.sum(det7_rate[:,6])
    else:
        det7_ch0_rate = 1000000
        det7_ch1_rate = 1000000
        det7_nulls = 0
    det7_ch0_unique_events_set = set(tup[8] for tup in det7_ch0)
    det7_ch1_unique_events_set = set(tup[8] for tup in det7_ch1)
    det7_ch0_unique_events = len(det7_ch0_unique_events_set)
    det7_ch1_unique_events = len(det7_ch1_unique_events_set)
    det7_ch_intersection = det7_ch0_unique_events_set & det7_ch1_unique_events_set
    det7_unique_count = len(set(tup[8] for tup in det7_list))
    det7_calc_rate = ((det7_ch0_rate+det7_ch1_rate) * request_rate * (2*10**-3))

    det8_ch0, det8_ch1 = ch_grouper(det8_list)
    det8_ch0_count = len(det8_ch0)
    det8_ch1_count = len(det8_ch1)
    det8_rate = np.array(det8_rate)
    if len(det8_rate)!=0:        
        det8_ch0_rate = np.mean(det8_rate[:,2])
        det8_ch1_rate = np.mean(det8_rate[:,4])
        det8_nulls = np.sum(det8_rate[:,6])
        det8_ur = np.sum(det8_rate[:,7])
        print("det8 ur:" , det8_ur)
    else:
        det8_ch0_rate = 1000000
        det8_ch1_rate = 1000000
        det8_nulls = 0
        det8_ur= 0
    det8_ch0_unique_events_set = set(tup[8] for tup in det8_ch0)
    det8_ch1_unique_events_set = set(tup[8] for tup in det8_ch1)
    det8_ch0_unique_events = len(det8_ch0_unique_events_set)
    det8_ch1_unique_events = len(det8_ch1_unique_events_set)
    det8_ch_intersection = det8_ch0_unique_events_set & det8_ch1_unique_events_set
    det8_unique_count = len(set(tup[8] for tup in det8_list))
    det8_calc_rate = ((det8_ch0_rate+det8_ch1_rate) * request_rate * (2*10**-3))

    det9_ch0, det9_ch1 = ch_grouper(det9_list)
    det9_ch0_count = len(det9_ch0)
    det9_ch1_count = len(det9_ch1)
    det9_rate = np.array(det9_rate)
    if len(det9_rate)!=0:        
        det9_ch0_rate = np.mean(det9_rate[:,2])
        det9_ch1_rate = np.mean(det9_rate[:,4])
        det9_nulls = np.sum(det9_rate[:,6])
    else:
        det9_ch0_rate = 1000000
        det9_ch1_rate = 1000000
        det9_nulls = 0
    det9_ch0_unique_events_set = set(tup[8] for tup in det9_ch0)
    det9_ch1_unique_events_set = set(tup[8] for tup in det9_ch1)
    det9_ch0_unique_events = len(det9_ch0_unique_events_set)
    det9_ch1_unique_events = len(det9_ch1_unique_events_set)
    det9_ch_intersection = det9_ch0_unique_events_set & det9_ch1_unique_events_set
    det9_unique_count = len(set(tup[8] for tup in det9_list))
    det9_calc_rate = ((det9_ch0_rate+det9_ch1_rate) * request_rate * (2*10**-3))

    det10_ch0, det10_ch1 = ch_grouper(det10_list)
    det10_ch0_count = len(det10_ch0)
    det10_ch1_count = len(det10_ch1)
    det10_rate = np.array(det10_rate)
    if len(det10_rate)!=0:        
        det10_ch0_rate = np.mean(det10_rate[:,2])
        det10_ch1_rate = np.mean(det10_rate[:,4])
        det10_nulls = np.sum(det10_rate[:,6])
    else:
        det10_ch0_rate = 1000000
        det10_ch1_rate = 1000000
        det10_nulls = 0
    det10_ch0_unique_events_set = set(tup[8] for tup in det10_ch0)
    det10_ch1_unique_events_set = set(tup[8] for tup in det10_ch1)
    det10_ch0_unique_events = len(det10_ch0_unique_events_set)
    det10_ch1_unique_events = len(det10_ch1_unique_events_set)
    det10_ch_intersection = det10_ch0_unique_events_set & det10_ch1_unique_events_set
    det10_unique_count = len(set(tup[8] for tup in det10_list))
    det10_calc_rate = ((det10_ch0_rate+det10_ch1_rate) * request_rate * (2*10**-3))
    
    det_data = (
        f'Health Statistics for File: {file_path}\n'

        f'\nTotal File Requests = {request_count}\n'

        f'\n###Array Detectors###'
        f'\nCh0 Count, Ch0 Unique Count, Ch0 Rate, Ch1 Count, Ch1 Unique Count, Ch1 Rate, Total Rate, Ch Intersection, Nulls, Total Unique Count, Total Replies, Measuered Data Transfer Rate, Calculated Data Transfer Rate\n'
        f'{det1_ch0_count}, {det1_ch0_unique_events}, {det1_ch0_rate}, {det1_ch1_count}, {det1_ch1_unique_events}, {det1_ch1_rate}, {det1_ch0_rate+det1_ch1_rate}, {len(det1_ch_intersection)}, {det1_nulls}, {det1_unique_count}, {det1_nulls+det1_unique_count}, {(len(det1_ch0)+len(det1_ch1))/3600}, {det1_calc_rate:.2f}\n' 
        f'{det2_ch0_count}, {det2_ch0_unique_events}, {det2_ch0_rate}, {det2_ch1_count}, {det2_ch1_unique_events}, {det2_ch1_rate}, {det2_ch0_rate+det2_ch1_rate}, {len(det2_ch_intersection)}, {det2_nulls}, {det2_unique_count}, {det2_nulls+det2_unique_count}, {(len(det2_ch0)+len(det2_ch1))/3600}, {det2_calc_rate:.2f}\n' 
        f'{det3_ch0_count}, {det3_ch0_unique_events}, {det3_ch0_rate}, {det3_ch1_count}, {det3_ch1_unique_events}, {det3_ch1_rate}, {det3_ch0_rate+det3_ch1_rate}, {len(det3_ch_intersection)}, {det3_nulls}, {det3_unique_count}, {det3_nulls+det3_unique_count}, {(len(det3_ch0)+len(det3_ch1))/3600}, {det3_calc_rate:.2f}\n' 
        f'{det4_ch0_count}, {det4_ch0_unique_events}, {det4_ch0_rate}, {det4_ch1_count}, {det4_ch1_unique_events}, {det4_ch1_rate}, {det4_ch0_rate+det4_ch1_rate}, {len(det4_ch_intersection)}, {det4_nulls}, {det4_unique_count}, {det4_nulls+det4_unique_count}, {(len(det4_ch0)+len(det4_ch1))/3600}, {det4_calc_rate:.2f}\n' 
        f'{det5_ch0_count}, {det5_ch0_unique_events}, {det5_ch0_rate}, {det5_ch1_count}, {det5_ch1_unique_events}, {det5_ch1_rate}, {det5_ch0_rate+det5_ch1_rate}, {len(det5_ch_intersection)}, {det5_nulls}, {det5_unique_count}, {det5_nulls+det5_unique_count}, {(len(det5_ch0)+len(det5_ch1))/3600}, {det5_calc_rate:.2f}\n' 
        f'{det6_ch0_count}, {det6_ch0_unique_events}, {det6_ch0_rate}, {det6_ch1_count}, {det6_ch1_unique_events}, {det6_ch1_rate}, {det6_ch0_rate+det6_ch1_rate}, {len(det6_ch_intersection)}, {det6_nulls}, {det6_unique_count}, {det6_nulls+det6_unique_count}, {(len(det6_ch0)+len(det6_ch1))/3600}, {det6_calc_rate:.2f}\n' 
        f'{det7_ch0_count}, {det7_ch0_unique_events}, {det7_ch0_rate}, {det7_ch1_count}, {det7_ch1_unique_events}, {det7_ch1_rate}, {det7_ch0_rate+det7_ch1_rate}, {len(det7_ch_intersection)}, {det7_nulls}, {det7_unique_count}, {det7_nulls+det7_unique_count}, {(len(det7_ch0)+len(det7_ch1))/3600}, {det7_calc_rate:.2f}\n' 
        f'{det8_ch0_count}, {det8_ch0_unique_events}, {det8_ch0_rate}, {det8_ch1_count}, {det8_ch1_unique_events}, {det8_ch1_rate}, {det8_ch0_rate+det8_ch1_rate}, {len(det8_ch_intersection)}, {det8_nulls}, {det8_ur}, {det8_unique_count}, {det8_nulls+det8_unique_count}, {(len(det8_ch0)+len(det8_ch1))/3600}, {det8_calc_rate:.2f}\n' 
        f'{det9_ch0_count}, {det9_ch0_unique_events}, {det9_ch0_rate}, {det9_ch1_count}, {det9_ch1_unique_events}, {det9_ch1_rate}, {det9_ch0_rate+det9_ch1_rate}, {len(det9_ch_intersection)}, {det9_nulls}, {det9_unique_count}, {det9_nulls+det9_unique_count}, {(len(det9_ch0)+len(det9_ch1))/3600}, {det9_calc_rate:.2f}\n' 
        f'{det10_ch0_count}, {det10_ch0_unique_events}, {det10_ch0_rate}, {det10_ch1_count}, {det10_ch1_unique_events}, {det10_ch1_rate}, {det10_ch0_rate+det10_ch1_rate}, {len(det10_ch_intersection)}, {det10_nulls}, {det10_unique_count}, {det10_nulls+det10_unique_count}, {(len(det10_ch0)+len(det10_ch1))/3600}, {det10_calc_rate:.2f}\n' 

    )
    
    stats_file_path = os.path.join(save_folder, 'det_data.txt')
    with open(stats_file_path, 'a') as f:
        f.write(det_data)
        f.write('\n')

    det1_data_int.append(((len(det1_list)/3600)/det1_calc_rate))
    det2_data_int.append(((len(det2_list)/3600)/det2_calc_rate))
    det3_data_int.append(((len(det3_list)/3600)/det3_calc_rate))
    det4_data_int.append(((len(det4_list)/3600)/det4_calc_rate))
    det5_data_int.append(((len(det5_list)/3600)/det5_calc_rate))
    det6_data_int.append(((len(det6_list)/3600)/det6_calc_rate))
    det7_data_int.append(((len(det7_list)/3600)/det7_calc_rate))
    det8_data_int.append(((len(det8_list)/3600)/det8_calc_rate))
    det9_data_int.append(((len(det9_list)/3600)/det9_calc_rate))
    det10_data_int.append(((len(det10_list)/3600)/det10_calc_rate))
    
    #det8_ur.append(det8_ur/3600)

    det1_wifi_int.append((det1_nulls+det1_unique_count)/(request_count))
    det2_wifi_int.append((det2_nulls+det2_unique_count)/(request_count))
    det3_wifi_int.append((det3_nulls+det3_unique_count)/(request_count))
    det4_wifi_int.append((det4_nulls+det4_unique_count)/(request_count))
    det5_wifi_int.append((det5_nulls+det5_unique_count)/(request_count))
    det6_wifi_int.append((det6_nulls+det6_unique_count)/(request_count))
    det7_wifi_int.append((det7_nulls+det7_unique_count)/(request_count))
    det8_wifi_int.append((det8_nulls+det8_unique_count)/(request_count))
    det9_wifi_int.append((det9_nulls+det9_unique_count)/(request_count))
    det10_wifi_int.append((det10_nulls+det10_unique_count)/(request_count))

def ur_req(data):
    
    grouped = defaultdict(list)

    for tup in data:
        grouped[tup[1]].append(tup[9])


    for id in grouped.keys():
        

        plt.plot(grouped[id], label = f'{id}:{len(grouped[id])}')
        groups = np.array(grouped[id])
        print(f"{id}: Mean={np.mean(groups)}; SD={np.std(groups)}")
        print(f"{id}: {len(groups[groups>13000])}")
        """if id == 20:
            print(f"{id}: {len(groups[groups>4000])}")
        elif id == 180:
            print(f"{id}: {len(groups[groups>9000])}")
        elif id == 252:
                    print(f"{id}: {len(groups[groups>14000])}")"""
        #print(f"{id}: {len(groups[groups>19000])}")
    
    plt.legend()
    plt.xlabel("UR #")
    plt.ylabel("Buffer Size")
    plt.title("Buffer Size at time of Unreasonable Request")
    plt.show()

def plotter(plot):
    data_int_list = [det1_data_int, det2_data_int, det3_data_int, det4_data_int, det5_data_int, det6_data_int, det7_data_int, det8_data_int, det9_data_int, det10_data_int]
    wifi_int_list = [det1_wifi_int, det2_wifi_int, det3_wifi_int, det4_wifi_int, det5_wifi_int, det6_wifi_int, det7_wifi_int, det8_wifi_int, det9_wifi_int, det10_wifi_int]
    det_num = [1,2,3,4,5,6,7,8,9,10]

    for data, wifi, num in zip(data_int_list, wifi_int_list, det_num):
        plt.scatter(np.arange(1, len((data))+1), data, label = "Data Integrity")
        plt.scatter(np.arange(1, len((wifi))+1), wifi, marker='x', label = "Wifi Integrity")
        avg_data_int = np.mean(data[1:len(data)-1])
        #avg_data_int = 0
        plt.title(f"Det {num} Data & Wifi Integrity\n Mean Data Integrity: {avg_data_int}")
        plt.ylabel(f"Integrity")
        plt.xlabel(f"Cycle Number")
        plt.ylim(-0.1,1.1)
        plt.legend()

        filename = f"{run_num} Det {num} Wifi and Data Integrity.png"
        filepath = os.path.join(save_folder, filename)
        plt.savefig(filepath, dpi=300)

        if plot:
            plt.show()
        
        plt.clf()

if __name__ == "__main__":

    with open('det_data.txt', 'w') as f:
        f.close()

    folder_pre = "C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data"
    run_num = "Run_10_20260213"

    save_folder_path = 'C:\\Users\\aclark2\\Desktop\\ESP 32\\Graphs\\'
    save_folder = os.path.join(save_folder_path, run_num)

    os.makedirs(save_folder, exist_ok=True)  
    folder_path = os.path.join(folder_pre, run_num)

    folder = folder_reader(folder_path)
    file = "gps_daq_20260213_run10_cycle0002.txt"
    #for file in folder:#os.listdir(folder_path):
    data_parser(file)
    
    #plotter(False)
    ur_req(ur_list)