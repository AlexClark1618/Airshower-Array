import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import os
from natsort import natsorted

data_path = "C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data\\"

folders = [
    # "Run_0023_20260311",
    # "Run_0024_20260311",
    # "Run_0025_20260313",
    # "Run_0026_20260315",
    # "Run_0027_20260316",
    # "Run_0028_20260317",
    # "Run_0029_20260318",
    # "Run_0030_20260319",
    # "Run_0031_20260320",
    # "Run_0032_20260324",
    # "Run_0033_20260401"
    "Run_0037_20260508"
]

folder_files_list = []     

for folder_name in folders:
    folder = os.path.join(data_path, folder_name)

    print(folder)

    for filename in os.listdir(folder):
        if filename.startswith('gps_daq'):
            file_path = os.path.join(folder, filename)
            if os.path.isfile(file_path):  # make sure it's a file
                file_name = file_path.replace("\\", "/")
                folder_files_list.append(file_name)


def timestamp_s(tup):
    """Combine ms and sub-ms into a single nanosecond timestamp"""
    return ((tup[5]*604800)+(tup[6]/1000)) 

Veto_ns_list = []
Veto_s_list = []
Veto_ns_list_cuts = []
Veto_s_list_cuts = []
for file in folder_files_list:
    print(file)
    with open(file, 'r') as f:

        next(f)

        for line in f:

            parts = line.strip().split(';')
            values = tuple(int(p.strip()) for p in parts) #Converts all elements to ints for easier analysis
        
            if values[0]==99 and values[6]>0 and values[1]==16 and values[4]==1 and values[2]==0 and values[3]==1: #Real data
                #if values[6]<604800000 and values[7]<1000000: #Ignore nonsense ms and ns timestamps
                Veto_ns_list.append(values[7])
                Veto_s_list.append(timestamp_s(values))
                if values[7]<1000:
                    Veto_ns_list_cuts.append(values[7])
                    Veto_s_list_cuts.append(timestamp_s(values))                
                if values[7]>500:
                    pass
                    #print(values)

Veto_ns_list = np.array(Veto_ns_list)
print(f"STD:{np.std(Veto_ns_list)} ns")

Veto_s_list = np.array(Veto_s_list)
print(f"Days of data: {(Veto_s_list[-1]-Veto_s_list[0])//86400}")

Veto_s_list = (Veto_s_list-Veto_s_list[0])/86400

plt.plot(Veto_s_list, Veto_ns_list)
plt.title("Gamma Veto PPS Variation")
plt.xlabel("Days Since Initial PPS")
plt.ylabel("Ns Timestamp")
plt.show()


Veto_ns_list_cuts = np.array(Veto_ns_list_cuts)
print(f"STD:{np.std(Veto_ns_list_cuts)} ns")

Veto_s_list_cuts = np.array(Veto_s_list_cuts)
print(f"Days of data: {(Veto_s_list_cuts[-1]-Veto_s_list_cuts[0])//86400}")

Veto_s_list_cuts = (Veto_s_list_cuts-Veto_s_list_cuts[0])/86400

plt.plot(Veto_s_list_cuts, Veto_ns_list_cuts)
plt.title("Gamma Veto PPS Variation (w/ Cuts)")
plt.xlabel("Days Since Initial PPS")
plt.ylabel("Ns Timestamp")
plt.show()