import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import os
from natsort import natsorted
from scipy import stats

connection_dict = defaultdict(list)

file = 'C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data\\Run_0031_20260320\\connection_log.txt'

conn_list = []

det_dict = {48:0, 16:0, 112:0, 180:0, 172:0, 64:0, 216:0, 252:0, 224:0, 20:0, 232:0, 164:0}


def connection_parser(file):

    cycles = {}
    current_cycle = None

    with open(file, 'r') as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            if line.startswith("Start Cycle"):
                current_cycle = int(line.split()[2].split(':')[0])
                cycles[current_cycle] = det_dict.copy() 
                continue

            if line.startswith("2026"):
                continue

            if ';' in line:
                try:
                    parts = [int(p.strip()) for p in line.split(';')]

                    if parts[0] == 1:
                        detector_id = parts[1]
                        cycles[current_cycle][detector_id] += 1

                except:
                    continue

    return cycles

conn_dict = (connection_parser(file))

#print(conn_dict[5].keys())

x = []
y = []
colors = []

for cycle, dets in conn_dict.items():
    for det, count in conn_dict[cycle].items():
        x.append(cycle)
        y.append(count)
        colors.append(det)  # color by detector

plt.scatter(x, y, c=colors, s=10)
plt.xlabel("Cycle")
plt.ylabel("Occurrences")
#plt.colorbar(label="Detector ID")
plt.show()