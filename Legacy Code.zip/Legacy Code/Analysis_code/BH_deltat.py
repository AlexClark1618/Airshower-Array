import numpy as np
import matplotlib.pyplot as plt
import os
from natsort import natsorted
from collections import defaultdict
from collections import Counter
import math



folder_pre = "C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data"
run_num = "Run_10_20260213"

folder_path = os.path.join(folder_pre, run_num)


#for file in folder:#os.listdir(folder_path):
#    data_parser(file)


def folder_reader(folder_path):
    global folder_files_list 
    folder_files_list = []     
    for filename in os.listdir(folder_path):
        if filename.startswith('gps_daq'):
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):  # make sure it's a file
                file_name = file_path.replace("\\", "/")
                folder_files_list.append(file_name)
    return natsorted(folder_files_list) #Correctly sorted them based on number


folder = folder_reader(folder_path)

"""def GPS_to_UTC(tup):

    return ((((tup[6]/1000)+(tup[7]/10**9))%86400)*10000) #To seconds"""
def timestamp_ns(tup):
    """Combine ms and sub-ms into a single nanosecond timestamp"""
    return ((tup[6] * 1000000) + tup[7]) 

BH_list = []
veto_list = []
det8_list = []
BH_dt_list = []
veto_dt_list = []
det8_dt_list = []
det8_ur_count = []
file = 'C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data\\Run_0020_20260227\\gps_daq_20260227_run0020_cycle0120.txt'

def data_parser(file):
    print(file)
    #if file.startswith("gps_daq"):
    file_path = os.path.join(folder_path, file)

    with open(file_path, 'r') as f:

        next(f) 
        for line in f:

            parts = line.strip().split(';')
            #print(parts)
            try:
                values = list(int(p.strip()) for p in parts) #Converts all elements to ints for easier analysis

            except Exception as e:
                print("Error", e)
                continue
            
            if values[0] ==96 and values[1]==20:
                det8_ur_count.append(values)

            if values[0] == 97:
                if values[1] == 48:
                    BH_dt_list.append(values)

                if values[1] == 16:
                    values[8] = values[8]
                    #print(values)
                    veto_dt_list.append(values)

                #if values[1] == 20:
                    #det8_dt_list.append(values)

            if values[0]==99 and values[6]!=0 and values[2]==0: #Real data
                if values[6]<604800000 and values[7]<1000000: #Ignore nonsense ms and ns timestamps
                    #all_data.append(values)

                    if values[1]==48 and values[4]==0:
 
                        BH_list.append(values)
                    
                    if values[1]==16 and values[4]==0:

                        veto_list.append(values)


                    

data_parser(file)
#print(BH_dt_list)

#ur_events = defaultdict(list)

#ur_request_set = set(tup[8] for tup in det8_ur_count)

#ur_request_set = [(x) for x in ur_request_set]

bh_events = defaultdict(list)
veto_events = defaultdict(list)

bh_data = BH_dt_list + BH_list
veto_data = veto_dt_list + veto_list

for tup in bh_data:
    bh_events[tup[8]].append(timestamp_ns(tup))

for tup in veto_data:
    veto_events[tup[8]].append(timestamp_ns(tup))

print(bh_events)
bh_diffs_list = [(val[1]-val[0])/1000000 for val in bh_events.values()]

print(bh_diffs_list)

plt.hist(bh_diffs_list, bins = 100)

veto_diffs_list = [(val[1]-val[0])/1000000 for val in veto_events.values()]

plt.hist(veto_diffs_list, bins = 100)
plt.show()


"""
events = defaultdict(list)

ur_request_diff = []
diff_list = []
bh_det8_diff = []
veto_det8_diff = []

data = veto_dt_list+BH_dt_list+det8_dt_list
#print(data)
for tup in data:
    #print(tup)
    events[tup[8]].append(tup[5])


for key in events.keys():
    
    #print(events[key])
    if len(events[key])>1: #total
        diff_list.append((events[key][1] - events[key][0])/10)
        if key in ur_request_set:
            ur_request_diff.append((events[key][1] - events[key][0])/10)

    if key<0 and len(events[key])>1:
        veto_det8_diff.append((events[key][1] - events[key][0])/10)
    
    if key>0 and len(events[key])>1:
        bh_det8_diff.append((events[key][1] - events[key][0])/10)

    

print(len(ur_request_diff))
print("Total UR Count for Det8:" ,len(det8_ur_count))
print("Total Delta T's:", len(diff_list))

diff_list.sort(reverse=True)
cut_off = diff_list[2117]
diff_list = np.array(diff_list)
print("Cut off Delta T:",cut_off)
print("Number of Delta T's > than cut off:", len(diff_list[diff_list>cut_off]))
print("Veto Delta T's:", len(veto_det8_diff))
print("BH Delta T's:", len(bh_det8_diff))

plt.hist(diff_list, bins = 100, label = "All Delta T's")
plt.hist(ur_request_diff, bins = 100, color='g', label = "Unreasonable Requests")
plt.axvline(x = cut_off, color = 'r', linestyle = '--' , label = f'Cutoff: {cut_off} ms')
plt.title(f"Delta T Distribution for Between BH/ Veto and det8 \n Mean = {np.mean(np.array(diff_list)):.2f} \n SD =  {np.std(np.array(diff_list)):.2f}")
plt.xlabel("Delta T (Det8 PPS - BH/Veto PPS) (ms)")
plt.ylabel("Count")
plt.yscale('log')
plt.legend()
plt.show()

plt.hist(veto_det8_diff, bins = 100)
plt.title(f"Delta T Distribution Between Veto and det8 \n Mean = {np.mean(np.array(veto_det8_diff)):.2f} \n SD =  {np.std(np.array(veto_det8_diff)):.2f}")
plt.xlabel("Delta T (Det8 PPS - Veto PPS) (ms)")
plt.ylabel("Count")
plt.yscale('log')

#plt.show()

plt.hist(bh_det8_diff, bins = 100)
plt.title(f"Delta T Distribution Between BH and det8 \n Mean = {np.mean(np.array(bh_det8_diff)):.2f} \n SD =  {np.std(np.array(bh_det8_diff)):.2f}")
plt.xlabel("Delta T (Det8 PPS - BH PPS) (ms)")
plt.ylabel("Count")
plt.yscale('log')

#plt.show()"""


