import numpy as np
import matplotlib.pyplot as plt
import os
from natsort import natsorted
from collections import defaultdict
from collections import Counter
import math

det1_data_int = []
det2_data_int = []
det3_data_int = []
det4_data_int = []
det5_data_int = []
det6_data_int = []
det7_data_int = []
det8_data_int = []
det9_data_int = []
det10_data_int = []

det1_wifi_int = []
det2_wifi_int = []
det3_wifi_int = []
det4_wifi_int = []
det5_wifi_int = []
det6_wifi_int = []
det7_wifi_int = []
det8_wifi_int = []
det9_wifi_int = []
det10_wifi_int = []

def ch_grouper(data): #Only risetimes
    '''
    This function splits the read data by channel number
    '''
    #Seperates data based on gps channel
    ch0_list = [tup for tup in data if tup[4]==0 and tup[2]==0]
    ch1_list = [tup for tup in data if tup[4]==1 and tup[2]==0]
    
    return ch0_list, ch1_list

def folder_reader(folder_path):
    global folder_files_list 
    folder_files_list = []     
    for filename in os.listdir(folder_path):
        if filename.startswith('gps_daq'):
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):  # make sure it's a file
                file_name = file_path.replace("\\", "/")
                folder_files_list.append(file_name)
    return natsorted(folder_files_list) #Correctly sorted them based on number

def data_parser(file):
    print(file)
    #if file.startswith("gps_daq"):
    file_path = os.path.join(folder_path, file)

    all_data = []

    BH_list = []
    Veto_list = []
    det1_list = []
    det2_list = []
    det3_list = []
    det4_list = []
    det5_list = []
    det6_list = []
    det7_list = []
    det8_list = []
    det9_list = []
    det10_list = []

    det1_rate1 = []
    det2_rate1 = []
    det3_rate1 = []
    det4_rate1 = []
    det5_rate1 = []
    det6_rate1 = []
    det7_rate1 = []
    det8_rate1 = []
    det9_rate1 = []
    det10_rate1 = []

    det1_rate = []
    det2_rate = []
    det3_rate = []
    det4_rate = []
    det5_rate = []
    det6_rate = []
    det7_rate = []
    det8_rate = []
    det9_rate = []
    det10_rate = []

    with open(file_path, 'r') as f:

        next(f) 
        for line in f:

            parts = line.strip().split(';')
            #print(parts)
            try:
                values = tuple(int(p.strip()) for p in parts) #Converts all elements to ints for easier analysis

            except Exception as e:
                print("Error", e)
                continue
            
            if values[0] == 95:  

                if values[1]==112:
                    det1_rate1.append(values)
                if values[1]==180:
                    det2_rate1.append(values)
                if values[1]==172:
                    det3_rate1.append(values)
                if values[1]==64:
                    det4_rate1.append(values)
                if values[1]==232:
                    det5_rate1.append(values)
                if values[1]==252:
                    det6_rate1.append(values)
                if values[1]==224:
                    det7_rate1.append(values)
                if values[1]==20:
                    det8_rate1.append(values) 
                if values[1]==104:
                    det9_rate1.append(values)
                if values[1]==164:
                    det10_rate1.append(values)

            if values[0] == 98:  

                if values[1]==112:
                    det1_rate.append(values)
                if values[1]==180:
                    det2_rate.append(values)
                if values[1]==172:
                    det3_rate.append(values)
                if values[1]==64:
                    det4_rate.append(values)
                if values[1]==232:
                    det5_rate.append(values)
                if values[1]==252:
                    det6_rate.append(values)
                if values[1]==224:
                    det7_rate.append(values)
                if values[1]==20:
                    det8_rate.append(values) 
                if values[1]==104:
                    det9_rate.append(values)
                if values[1]==164:
                    det10_rate.append(values)

            if values[0]==99 and values[6]!=0 and values[2]==0: #Real data
                if values[6]<604800000 and values[7]<1000000: #Ignore nonsense ms and ns timestamps
                    all_data.append(values)

                    if values[1]==48 and values[4]==0:
                        BH_list.append(values)
                    if values[1]==16:
                        Veto_list.append(values)
                    if values[1]==112:
                        det1_list.append(values)
                    if values[1]==180:
                        det2_list.append(values)
                    if values[1]==172:
                        det3_list.append(values)
                    if values[1]==64:
                        det4_list.append(values)
                    if values[1]==232:
                        det5_list.append(values)
                    if values[1]==252:
                        det6_list.append(values)
                    if values[1]==224:
                        det7_list.append(values)
                    if values[1]==20:
                        det8_list.append(values)   
                    if values[1]==104:
                        det9_list.append(values)
                    if values[1]==164:
                        det10_list.append(values)



    request_count = (len(BH_list)+len(Veto_list))
    print("req count:", request_count)
    request_rate = (len(BH_list)+len(Veto_list))/3600

    det1_ch0, det1_ch1 = ch_grouper(det1_list)
    det1_ch0_count = len(det1_ch0)
    print("a",(det1_ch0_count))
    det1_ch1_count = len(det1_ch1)
    det1_rate = np.array(det1_rate)
    det1_rate1 = np.array(det1_rate1)

    
    det1_ch0_c = (det1_rate[:,2])
    #print(det1_ch0_c)
    det1_ch1_rate = np.mean(det1_rate[:,4])
    deltaT = (det1_rate[:,4]/1000)
    #print(deltaT)
    det1_ch0_rate = np.mean(det1_ch0_c/deltaT)
    print(det1_ch0_rate)
    det1_ch0_nulls = np.sum(det1_rate[:,8])+np.sum(det1_rate1[:,2])
    print("det1 nulls:", det1_ch0_nulls)
    

    det1_ch0_unique_events_set = set(tup[8] for tup in det1_ch0)

    det1_ch1_unique_events_set = set(tup[8] for tup in det1_ch1)
    det1_ch0_unique_events = len(det1_ch0_unique_events_set)
    print("b", det1_ch0_unique_events)
    det1_ch1_unique_events = len(det1_ch1_unique_events_set)
    det1_ch_intersection = det1_ch0_unique_events_set & det1_ch1_unique_events_set
    det1_unique_count = len(set(tup[8] for tup in det1_list))
    det1_calc_rate = ((det1_ch0_rate+det1_ch1_rate) * request_rate * (2*10**-3))

if __name__ == "__main__":

    with open('det_data.txt', 'w') as f:
        f.close()

    folder_pre = "C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data"
    run_num = "Run_0012_20260220"

    save_folder_path = 'C:\\Users\\aclark2\\Desktop\\ESP 32\\Graphs\\'
    save_folder = os.path.join(save_folder_path, run_num)

    os.makedirs(save_folder, exist_ok=True)  
    folder_path = os.path.join(folder_pre, run_num)

    folder = folder_reader(folder_path)
    file = "gps_daq_20260220_run0012_cycle0002.txt"
    #for file in folder:#os.listdir(folder_path):
    data_parser(file)
    