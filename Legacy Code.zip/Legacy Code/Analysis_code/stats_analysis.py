import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import os
from natsort import natsorted
from collections import defaultdict
from collections import Counter


file= "C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data\\gps_daq_20260320_run0001_cycle0001.txt"

def folder_reader(folder_path):
    global folder_files_list 
    folder_files_list = []     
    for filename in os.listdir(folder_path):
        if filename.startswith('gps_daq'):
            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):  # make sure it's a file
                file_name = file_path.replace("\\", "/")
                folder_files_list.append(file_name)
    return natsorted(folder_files_list) #Correctly sorted them based on number

deltaT_data = defaultdict(list)

proc_time_data = defaultdict(list)
transit_time_data = defaultdict(list)
ur_data = defaultdict(list)
ur_count = defaultdict()
ram_usage = defaultdict(list)

all_detectors = [232, 20, 180, 252, 216, 172, 224, 164, 64, 112]

def stats_parser(file):
    print(file)
    
    with open(file, 'r') as f:

            next(f) 

            for line in f:

                parts = line.strip().split(';')
                #print(parts)
                try:
                    values = tuple(int(p.strip()) for p in parts) #Converts all elements to ints for easier analysis

                except Exception as e:
                    print("Error", e)
                    continue
                
                if values[0] == 93: #Unreasonable Requests
                    detector_id = values[1]
                    ur_data[detector_id].append(values) 

                if values[0] == 96: #
                    detector_id = values[1]
                    proc_time_data[detector_id].append(values[2:6])

                if values[0] == 97 and values[1]!=48 and values[1]!=16: #
                    detector_id = values[1]
                    transit_time_data[detector_id].append(values[2:9])

                if values[0] == 98: #
                    detector_id = values[1]
                    deltaT_data[detector_id].append(values[2:9])
                
                if values[0] == 92: #
                    detector_id = values[1]
                    ram_usage[detector_id].append(values[2:5])
    #return ur_data

stats_parser(file)
#Code 96- Proc Time

for det_id in sorted(deltaT_data):
    if det_id == 232:

        array = np.array(deltaT_data[det_id])

        deltaT = array[:,2]
        deltaT_sum = np.sum(array[:,2])
        print(deltaT_sum/1000)
        #print(deltaT)
        ts = array[:,4]
        ts_diffs = np.diff(ts)
        #print(ts_diffs)
        
        plt.plot(deltaT)

        plt.title(f"GPS Time Stamp {det_id}")
        plt.xlabel("5s Interval")
        plt.ylabel("Time (us)")
        plt.legend()
        #plt.show()
plt.clf()    

for det_id in sorted(proc_time_data):
    if det_id == 232 or det_id == 116:

        array = np.array(proc_time_data[det_id])
        plt.plot(array[:,0], label=f"Avg Proc Time | Mean: {np.mean(array[:,0]):.2f} ms")
        #plt.plot(array[:,1], label="Max Proc Time")
        plt.plot(array[:,2][array[:,2]<1000], label=f"Avg Loop Time | Mean: {np.mean(array[:,2][array[:,2]<1000]):.2f} ms")
        #plt.plot(array[:,3], label="Max Loop Time")

        plt.title(f"Average Processing & Loop Time For Detector ID {det_id}")
        plt.xlabel("5s Interval")
        plt.ylabel("Time (ms)")
        plt.legend()
        #plt.show()
plt.clf()    

for det_id in sorted(ram_usage):
    if det_id == 232 or det_id == 116:

        array = np.array(ram_usage[det_id])
        plt.plot(array[:,1], label=f"Avg Ram Usage | Mean: {np.mean(array[:,1]):.2f} kB")
        plt.plot(array[:,2], linestyle='--', color = 'r' ,label="Max Available Ram")
        #plt.plot(array[:,3], label="Max Loop Time")

        plt.title(f"Average Ram Usage for Detector ID {det_id}")
        plt.xlabel("5s Interval")
        plt.ylabel("Time (ms)")
        plt.legend()
        plt.yscale('log')
        plt.show()
plt.clf()    

for det_id in sorted(proc_time_data):
    if det_id == 232 or det_id == 164:

        array = np.array(proc_time_data[det_id])

        plt.plot(array[:,2], label="Avg Loop Time")
        plt.plot(array[:,3], label="Max Loop Time")

        plt.title(f"Average Vs Maximum Loop Time For Detector ID {det_id}")
        plt.xlabel("5s Interval")
        plt.ylabel("Time (us)")
        plt.legend()
        #plt.show()
plt.clf()
#Code 97- Transit Time

print(transit_time_data.keys())
for det_id in sorted(transit_time_data):
    if det_id == 20 or det_id == 180:
        array = np.array(transit_time_data[det_id])

        plt.plot(array[:,0], label="Avg Transit Time")
        plt.plot(array[:,1], label="Min Transit Time")
        plt.plot(array[:,2], label="Max Tranist Time")


        plt.title(f"Tranist Time for Detector ID {det_id}")
        plt.xlabel("5s Interval")
        plt.ylabel("Time (ms)")
        plt.legend()

        #plt.show()
plt.clf()    

for det_id in sorted(transit_time_data):
    if det_id == 20 or det_id == 180:
        array = np.array(transit_time_data[det_id])

        plt.plot(array[:,3], label="Avg Req Bunching")
        plt.plot(array[:,4], label="Max Bunching")
        plt.plot(array[:,5], label="Unreasonable Request Count")


        plt.title(f"Req Bunching vs Unreasonable Request Count Detector ID {det_id}")
        plt.xlabel("5s Interval")
        plt.ylabel("Counts")
        plt.legend()

        #plt.show()
plt.clf()    


def ur_plotter():
    files_list = folder_reader(data_folder)
    colors = plt.cm.tab10.colors

    for i in range(0, len(files_list), 5):
        file = files_list[i]
        ur_data = stats_parser(file)
        det_ids = sorted(ur_data.keys())

        for j, det_id in enumerate(all_detectors):

            if det_id == 20 or det_id == 164:
                y = len(ur_data[det_id]) + 1
                print(f'{det_id}:{y}')
                #print(len(ur_data[64]))
                plt.scatter(i+1, y, color=colors[j], label=f"Det {det_id}" if i == 0 else "")
        ur_data.clear()

    plt.xlabel("File Index")
    plt.ylabel("Counts per Detector")
    plt.title("Unreasonable Requests Evolutions")
    plt.yscale('log')
    #plt.ylim(0,200)
    plt.legend()
    plt.show()

    '''
    req_diff = array[:,7]
    print("Total UR:", len(req_diff))
    req_diff = req_diff[req_diff<50000000]
    req_diff_less_than_50 = req_diff[abs(req_diff)<50]

    print("Number of UR with Delta T between 0 and 50ms:", sum(1 for tup in req_diff_less_than_50 if tup>0))
    print("Number of UR with positive Delta T:", sum(1 for tup in req_diff if tup>0))
    print("Number of UR with negative Delta T:",sum(1 for tup in req_diff if tup<0))
    print(f"Percentage of UR with Delta T's in +-50ms window: {(len(req_diff_less_than_50)/len(req_diff))*100:.2f}")
    #print(max(req_diff))

    plt.hist(req_diff, bins=200)
    plt.xlim(-500,500)
    plt.xlabel("DeltaT (ms)")
    plt.title(f"Unreasonable Requests: DeltaT from Previous Request {det_id}")
    #plt.yscale('log')
    plt.show()

    trans_time = array[:,6]
    print(np.mean(trans_time))

    plt.hist(trans_time, bins=100)
    #plt.xlim(-1000,1000)
    #plt.yscale('log')
    plt.xlabel("Transit Time (ms)")
    plt.title(f"Unreasonable Requests: Tranist Time {det_id}")

    plt.show()
    '''

'''
if __name__ == "__main__":
    
    #Data Filter min & max
    min = 1
    max = 99
    
    #Run ID and folder paths
    run_num = 'Run_0026_20260315'

    save_folder_path = 'C:\\Users\\aclark2\\Desktop\\ESP 32\\Graphs\\'
    save_folder = os.path.join(save_folder_path, run_num)

    os.makedirs(save_folder, exist_ok=True)  



    data_folder_path = 'C:\\Users\\aclark2\\Desktop\\ESP 32\\GPS Data\\'
    data_folder = os.path.join(data_folder_path, run_num)

    DATA_FILE = 'C:\\Users\\aclark2\\Desktop\\ESP 32\\joined_file.txt' #Automatically use joined file


    #file_joiner()
    #read_data(DATA_FILE, False) #Call read data with joined file
    #ur_plotter()

'''