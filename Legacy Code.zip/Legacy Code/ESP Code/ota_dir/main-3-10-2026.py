#Updated- 10-28-25 (Sent from Jean-Luc)

# OTA Update is working with ESP32 streaming data to Karbon Computer when I send the OTA Update from my macbook
# OTA update is unreliable when sent from Karbon computer

#Changelog:
    #Altered diff in request function
    #Fixed error in how sockets were reconnecting
    #
import array, gc
#from micropython import alloc_emergency_exception_buf


gc.collect()
#alloc_emergency_exception_buf(256)

# CAPACITY_RAW =  4092
# CAPACITY_CAL = 256
# raw_write_idx = [0]
# raw_count     = [0]
# cal_write_idx = [0]
# cal_count     = [0]

from ringBuffer import RingBuffer, push_all_cal, push_all_raw
from ringBuffer import rb_cal_count, rb_cal_wno, rb_cal_ms, rb_cal_sub
from ringBuffer import rb_raw_rf, rb_raw_ch, rb_raw_count, rb_raw_wno, rb_raw_ms, rb_raw_sub
from ringBuffer import CAPACITY_RAW, CAPACITY_CAL, raw_write_idx, cal_write_idx, cal_count, raw_count

gc.collect()
# print("free mem1", gc.mem_free())
# rb_raw_count = RingBuffer('I', CAPACITY_RAW, raw_write_idx,  raw_count)
# gc.collect()
# print("free mem2", gc.mem_free())
import time
import network
# ssid = 'TP-LINK-G'
# password = '1A3d!5da7Ph@t9'
# HOST='192.168.68.61'
# wlan = network.WLAN(network.STA_IF)
# network.WLAN(network.AP_IF).active(False)
# wlan.active(True)
# wlan.connect(ssid, password)
# time.sleep(1)

#gc.collect()
from machine import UART, Pin, WDT, freq as clockFreq
uart1_tx_pin = 12  # Example: GPIO12
uart1_rx_pin = 14  # Example: GPIO14
rxbuf = 23000  #(8192 * 3 ) # 24kB seems to be the max allowed within the code.
# uart1 = UART(1)
# uart1.deinit()
# uart1 = UART(1, baudrate=115200*4, tx=Pin(uart1_tx_pin), rx=Pin(uart1_rx_pin))
uart1 = UART(1, baudrate=115200*4, tx=Pin(uart1_tx_pin), rx=Pin(uart1_rx_pin), rxbuf=rxbuf)
clockFreq(240_000_000)

import socket
import ustruct
#import time
#import gc
import random
import _thread
from sys import exit, print_exception
print("free mem before esp_pps ", gc.mem_free())
#from ESP_PPS_SYNC import rtc_to_gps_wno_ms_subms
#import ESP_PPS_SYNC
#import rtc_to_gps_wno_ms_subms
#init_time()

#from ESP_PPS_SYNC import init_time, pps_irq, ubx_checksum, ubx_send, ubx_recv, poll_gps_time, discipline_rtc,rtc_to_gps_wno_ms_subms
print("free mem after", gc.mem_free())
#UBX_HDR = b'\xb5\x62' # \xb5\x62
RXM_TM =(2,116)   #b'\x02\x74'
TIM_TM2= (13,3)   #b'\x0d\x03'
NAV_CLOCK= (1,34)       #b'\x01\x22'
REQUESTED_TIME_WINDOW = 1000000  #returned times (ns) will be within +/- requested_time_window of time of interested 
# UBX poll message for NAV-CLOCK (class 0x01, ID 0x22)
POLL_NAV_CLOCK = b'\xb5\x62\x01\x22\x00\x00\x23\x6a'

# ─── Shared read/write state for the RAW group ──────────────────────────────
gc.collect()
# raw_write_idx=[0]
# raw_count=[0]
# cal_write_idx=[0]
# cal_count=[0]


# time.sleep(0.1)
#NNC=10
numMeas=1
#global RFRaw, chRaw, countRaw, countCal, towMsRaw, towMsCal,towSubMsRaw, towSubMsCal
#    global slope , deltaT, Nevents0, Nevents1

# global tcoll0
# tcoll0=0
# ---------- Wi-Fi Setup ----------
#Location='GG'
#Location='Home'
#Location='GG'
Location='Oxy'
print(Location)
if Location == 'Home':
   ssid = 'TP-LINK-G'
   password = '1A3d!5da7Ph@t9'
   HOST='192.168.68.61'
elif Location == 'GG':
   ssid = 'TMOBILE-D4F2'
   password = 'bck37dsv6t5'
   HOST='192.168.12.176'
elif Location == 'Oxy':
   ssid = 'ONet'
   password = ''
   HOST='134.69.216.235'
elif Location == 'iPhone':
   ssid = 'I Phone'
   password = 'gauv1244'
   HOST='172.20.10.2'
else:
    print(Location,'not found')

gc.collect()
print("free_mem",gc.mem_free())
#These can be moved to the main wifi function, but I thinks its more versitile to define them as globals
wlan = network.WLAN(network.STA_IF)
#network.WLAN(network.AP_IF).active(False)
wlan.active(True)
# Turn off power saving
wlan.config(pm=network.WLAN.PM_NONE)
#wlan.ifconfig(('169.254.241.89', '255.255.0.0', '134.69.192.7', '134.69.192.7'))  # Example; use a free IP, correct subnet/gateway/DNS
#wlan.ifconfig(('10.0.0.7', '255.255.255.0', '10.0.0.1', '10.0.0.1'))  # Example; use a free IP, correct subnet/gateway/DNS
mac_id = wlan.config('mac')[-1]  # last byte of MAC
#print(type(mac_id))
print('mac id:', mac_id)

PORT = 12345

#Socket Stuff

# ---------- Functions ----------
wdt = WDT(timeout=10000)

#---------OTA Function------------

def start_listener():
  try:  
    addr = socket.getaddrinfo('0.0.0.0', 8080)[0][-1]
    s = socket.socket()
    s.bind(addr)
    s.listen(1)
    print("Listening for OTA trigger on port 8080...")

    while True:
        cl, addr = s.accept()
        print('Client connected from', addr)
        request = cl.recv(1024)
        request = str(request)

        if "/ota" in request:
            print("OTA trigger received")
            cl.send("HTTP/1.1 200 OK\r\n\r\nUpdating...\n")
            ota_update.download_and_install(cl)
        else:
            print("No OTA trigger received")
            cl.send(b"HTTP/1.1 200 OK\r\n\r\nHello from ESP32\n")
            cl.close()
  except exception as e:
      print('start_listener error:',e)


#It clears 500bytes in 100 + 500 = 600us --> t = (100+Nbytes)us

def clearRxBuf():
    print('clearRxBuf')
    gc.collect()
    try:
        #print('clearRxBuf:', uart1.any(),'bytes')
        print('buffer cleared of ',uart1.any(), 'bytes\n')
        while uart1.any()>1024:
            junk=(uart1.read(1024))
        while uart1.any():
            uart1.read()
    except Exception as e:
        print("clearRxBuffer error:",e)
        sys.print_exception(e)
        #error_msg = (100, mac_id, 1, 0, 0, 0, 0, 0, 0)
        #packet = data_packing(send_packet_format, error_msg)
        #s.send(packet)
        pass

def wifi_reset():
    wlan.active(False)
    time.sleep(0.5)
    wlan.active(True)
    time.sleep(0.5)


def con_to_wifi(ssid, password, timeout=10):
  try:
    if wlan.isconnected():
        print("Already connected")
        return wlan.ifconfig()

    print("Connecting to Wi-Fi...")
    wifi_reset()    
    wlan.connect(ssid, password)

    start = time.ticks_ms()
    while not wlan.isconnected():
        if time.ticks_diff(time.ticks_ms(), start) > timeout * 1000:
            raise RuntimeError("Wi-Fi connection timeout")
        time.sleep(0.2)

    print("Wi-Fi connected")
    return wlan.ifconfig()
  except Exception as e:
    print("con_to_wifi error:", e)

  


def connect_socket(host, port):
  try:
    print("socket connecting to ", host, port)
    addr = socket.getaddrinfo(host, port)[0][-1]
    print("Connecting to:", addr)  # Verify address looks right
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect(addr)
#        s.connect((host, port))
        print("Socket connected.")
        wdt.feed()
        #clearRxBuf()
        return s
    except Exception as e:
        print("Failed to connect socket:", e)
        print(gc.mem_free())
        #error_msg = (100, mac_id, 8, 0, 0, 0, 0, 0, 0)
        #packet = data_packing(send_packet_format, error_msg)
        #s.send(packet)
  except Exception as e:
      print("connect_socket: error", e)


def data_packing(packet_format: str, msg: tuple):
    try:
        packet = ustruct.pack(packet_format, 
            msg[0],#inst,            # char (1 byte)
            msg[1],#ID,
            msg[2],#RF,              # char (1 byte)
            msg[3],#cal,              # uint8 (1 byte)
            msg[4],#ch,          # uint8 (1 byte)
            msg[5],#w_num,      	 # uint32 (4 bytes) #Q for 8 byte uint64
            msg[6],#ms,         # uint32 (4 bytes)
            msg[7],#sub_ms,
            msg[8],#event_num                  # uint32 (4 bytes)
            msg[9] #count
        )
        
        return packet
    except Exception as e:
        print("Error in data packing", e)
        #error_msg = (100, mac_id, 7, 0, 0, 0, 0, 0, 0, 0)
        #packet = data_packing(send_packet_format, error_msg)
        #s.send(packet)
        
def reconnect_socket(sock):
    try:
        if sock:
            sock.close()
    except Exception as e:
        print("Error closing socket:", e)
        error_msg = (100, mac_id, 9, 0, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        #s.send(packet)
    time.sleep(.1)
    return connect_socket(HOST, PORT)

def clear_wifi_rx_buffer(sock):      
    if not sock:
        print("No socket to clear.") 

    try:
        
        data = sock.recv(1024)
     
        print("Wifi RX buffer cleared of:", len(data), "bytes")
    except Exception as e:
        print("Error during buffer clear:", e)
        print_exception(e)
        
        error_msg = (100, mac_id, 10, 0, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        s.send(packet)
        


# ---------- GPS Functions ----------
junk=bytearray(1024)

def maxRxBuf(n):
#     global RFRaw, chRaw, countRaw, countCal, towMsRaw, towMsCal,towSubMsRaw, towSubMsCal
    #print('maxRxBuf')
    try:
        if uart1.any() > n:
            nClear=0
            while (uart1.any() > n-1000):
                #nskim = uart1.any()-n + 1000
                nClear += 1
                junk=uart1.read(1024)
            print('buffer cleared of ',nClear, 'kB\n')
    except Exception as e:
        print('maxRxbuf exception',e)
        error_msg = (100, mac_id, 2, 0, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        s.send(packet)


hdr = bytearray(1)
def findUBX_HDR():
  try:
    state = 0  # 0 = looking for 0xB5, 1 = looking for 0x62
    n=0
    i=0
    while True:
        if uart1.any() == 0:
            i=i+1
            time.sleep_ms(1)
            if (i-i//1000*1000) == 0:
                print('ubx',end='.')
            continue

        uart1.readinto(hdr)  # integer, no bytes object
        b = hdr[0]
        n=n+1
        #print(b,end=' ')
        if state == 0:
            if b == 0xB5:
                state = 1
        else:
            if b == 0x62:
                return n # header found
            else:
                state = 0            

  except Exception as e:
    print("findUBX_HDR error:",e)
    error_msg = (100, mac_id, 3, 0, 0, 0, 0, 0, 0)
    packet = data_packing(send_packet_format, error_msg)
    s.send(packet)

hdr2 = bytearray(4)
def findHDR2():
    while uart1.any() < 4:
        time.sleep_ms(1)
    uart1.readinto(hdr2)
    cls  = hdr2[0]
    msg  = hdr2[1]
    leni = hdr2[2] | (hdr2[3] << 8)
    return cls, msg, leni


MAX_TOI=64

toi_RF     = array.array("B", bytearray(MAX_TOI))
toi_valid     = array.array("B", bytearray(MAX_TOI))
toi_ch     = array.array("B", bytearray(MAX_TOI))
toi_wno     = array.array("H", bytearray(MAX_TOI))
toi_Ms     = array.array("I", bytearray(MAX_TOI))
toi_SubMs     = array.array("I", bytearray(MAX_TOI))

#instead of:
# toi_RF      = [0] * MAX_TOI
# toi_valid   = [0] * MAX_TOI
# toi_ch      = [0] * MAX_TOI
# toi_wno     = [0] * MAX_TOI
# toi_Ms      = [0] * MAX_TOI
# toi_SubMs   = [0] * MAX_TOI
#toi_count   = [0] * MAX_TOI

def request(wnoToi,MsToi,subMsToi):
        global slope, toi_len, tRaw1, tCal1, t,tIdx
#    #global RFRaw, chRaw, countRaw, countCal, towMsRaw, towMsCal,towSubMsRaw, towSubMsCal
#    try:
    #if True:
        #print('100')
        res=(0,0,0,0)
        t[tIdx]=time.time_ns()//1000
        tIdx += 1

        if (wnoToi == -1):
          #New request
          #print('request(-1,0,0) called')
          #time.sleep_ms(100)
          while (res[0] == 0):
              #print('res[0] ==0')
              res=readData(1)
              #print('readData(1)')
#          print('res[1]:',res[1])
          MsToi = res[1]+MsToi
          #print("MsToi",MsToi)
          subMsToi = res[2]
          #print('end if')
        t[tIdx]=time.time_ns()//1000
        tIdx += 1

        resToi=MsToi*1000000+subMsToi
        #print("diff", diff)
        # request is later than now or if request is sooner than start of additional buffer the U.Req.
        #print(rtc_to_gps_wno_ms_subms())
        #print(res)
        #wno, Ms, subMs = rtc_to_gps_wno_ms_subms()
        oldestMsCal=rb_cal_ms.get_oldest()
        if ((MsToi < oldestMsCal)) or ((res[0] != wnoToi) and (wnoToi != -1)):
            pass
        #if ((diff > REQUESTED_TIME_WINDOW) or (diff < -1000000000))  or ((res[0] != wnoToi) and (wnoToi != -1)):
            #print('##################################Unreasonable request', towMsCal[0], Ms, MsToi)
        #if ((diff > REQUESTEDimport _TIME_WINDOW) or (diff < -1000000000))  or ((res[0] != wnoToi) and (wnoToi != -1)):
            #print('Unreasonable request', Ms, oldestMsCal, MsToi)
            #unreas_count += 1
            
        t[tIdx]=time.time_ns()//1000
        tIdx += 1
        diff=0
       # Loop until res > Toi+ 1ms
        while (diff < REQUESTED_TIME_WINDOW):  # | (bytehdr2 == RXM_TM): #Exceed the time of interest by at least 1 ms and capture an extra RXM data packet    
            res=readData(1)
            if res[1] > 0:
                diff=(res[1]-MsToi)*1000000+(res[2]-subMsToi)
        t[tIdx]=time.time_ns()//1000
        tIdx += 1

        timeValid = res[3]
        #Find cal near toi
        calIdx=0
        for i in range(cal_count[0]):
            rbCal = rb_cal_ms.get(i)
            if rbCal < MsToi:
                if i > 0:
                    calIdx=i-1   #Cal index near toi 
                break
        t[tIdx]=time.time_ns()//1000
        tIdx += 1

        #find index where rawcount = calcount
        #print(calIdx)
        CCoI = rb_cal_count.get(calIdx)
        rawIdx=0
        for i in range(raw_count[0]):
            RC = rb_raw_count.get(i)
            if RC == 0:
                continue
            if RC < CCoI:
                break
            if RC == CCoI:  # matching raw count found
                tCal1 = rb_cal_ms.get(calIdx)*1000000 + rb_cal_sub.get(calIdx)
                tRaw1 = rb_raw_ms.get(i)*1000000 + rb_raw_sub.get(i)//1000
                rawIdx = i
                break
        #Calibrate raw data and select time near toi    
#         rfoi=[]; tvoi=[]; choi=[]; wnoi=[]; msoi=[]; submsoi=[]; countoi=[]
        t[tIdx]=time.time_ns()//1000
        tIdx += 1
        toi_len=0
        rawIdx=rawIdx-40  #starts about 50ms before toi
        rawIdx = max(rawIdx,0)

        #print(slope)
        #calibrate and select toi
        for i in range(rawIdx, raw_count[0]):
            tRaw=rb_raw_ms.get(i)*1000000+ rb_raw_sub.get(i)//1000
            #print(tRaw1)
            dtRaw=tRaw-tRaw1
            res=dtRaw-dtRaw*slope//1000000000 + tCal1
            diff = res - resToi
#            print("tRaw, dtRaw, res, resToi, diff", tRaw, dtRaw, res, resToi, diff)
            if diff < (-REQUESTED_TIME_WINDOW):
                # Reached t < toi
                break
            diff = abs(diff)
            if diff < REQUESTED_TIME_WINDOW:
                toi_RF[toi_len]=rb_raw_rf.get(i)
                toi_valid[toi_len]=timeValid
                toi_ch[toi_len]=rb_raw_ch.get(i)
                toi_wno[toi_len]=rb_raw_wno.get(i)
                toi_Ms[toi_len]=res//1000000
                toi_SubMs[toi_len]=res-toi_Ms[toi_len]*1000000
                toi_len +=1
        
        return(toi_RF,toi_valid,toi_ch,toi_wno,toi_Ms,toi_SubMs)

plb = bytearray(2048)
ck  = bytearray(2)
oldcount=0

def readData(det):
    global raw_write_idx, raw_count, cal_write_idx, cal_count
    global slope , deltaT, NEvents0, NEvents1,oldcount, oldtowMsR,oldtowMs
#    global RFRaw, chRaw, countRaw, countCal, towMsRaw, towMsCal,towSubMsRaw, towSubMsCal
    #print('0 readData free mem:',gc.mem_free())
#    print(raw_write_idx[0])
    #try:
    if (True):
        # Find UBX sync
        n=findUBX_HDR()
        if n>2:
            print("findUBX",n)
        #print('1 readData free mem:',gc.mem_free())

        cls, msg, leni = findHDR2()
        if leni > 2048:
            print("leni >2048" )
            return (0, 0, 0, 0)

        # Wait cooperatively for payload + checksum
        needed = leni + 2
        i=0
        while uart1.any() < needed:
            i=i+1
            if (i-i//1000*1000) == 0:
                print('readData',end='.')
            time.sleep_ms(1)

        # Read payload + checksum without allocating
        uart1.readinto(plb, leni)
        uart1.readinto(ck, 2)
        #print('2 readData free mem:',gc.mem_free())

        # ---------- RXM-TM ----------
        if (cls, msg) == RXM_TM:
            #print('RXM_TM')
            version = plb[0]
            numMeas = plb[1]
            
            #using 50ms windows
            deltaT += 50            
            base = 8
            for ii in range(numMeas):
                edgeInfo = (
                    plb[base+0] |
                    (plb[base+1] << 8) |
                    (plb[base+2] << 16) |
                    (plb[base+3] << 24)
                )

                RF = (edgeInfo >> 4) & 1
                ch = edgeInfo & 1

                count = plb[base+4] | (plb[base+5] << 8)
                wno   = plb[base+6] | (plb[base+7] << 8)

                towMs = (
                    plb[base+8] |
                    (plb[base+9] << 8) |
                    (plb[base+10] << 16) |
                    (plb[base+11] << 24)
                )

                towSubMs = (
                    plb[base+12] |
                    (plb[base+13] << 8) |
                    (plb[base+14] << 16) |
                    (plb[base+15] << 24)
                )

                #print('3 readData free mem:',gc.mem_free())
                #oldcount=count
                
                if (RF == 0):
                    if ((count-oldcount)%65536 !=1) :
                        print('RX-TM',count,oldcount)
                    oldcount=count
#                 RFRaw.append(RF)
#                 chRaw.append(ch)a
#                 countRaw.append(count)
                #print("countRawLen", len(countRaw))
#                 if (len(towMsRaw) > 1) and ii == 0:
#                     deltaMs = towMs-towMsRaw[-1]
#                     if (deltaMs < 2) or (deltaMs > 3):
#                         print("******************delta Ms",deltaMs)
#                 towMsRaw.append(towMs)
#                 towSubMsRaw.append(towSubMs)
                #print('4 readData free mem:',gc.mem_free())
#                print("push",end='.')
                if RF==0:
                    if ch==0:
                        NEvents0 +=1
                    elif ch==1:
                        NEvents1 +=1
                dtMs=towMs-oldtowMs
                if (dtMs)>75:
                    #countdtMs += 1
                    print ("count, towMs, oldtowMs, dt", count, towMs, oldtowMs,dtMs)
                oldtowMs=towMs

                push_all_raw(rf=RF, ch=ch, wno=wno, ms=towMs, sub=towSubMs, count=count)
#To be dona all over
#                 if raw_write_idx == 0:
#                     R_ch = sum(rb_raw_ch)
#                     N_ch = CAPACITY_RAW-R_ch
#                     tNow=rb_raw_ms.get(0)
#                     if tOld == 0:
#                         tOld = rb_raw_ms.get_oldest()
#                     deltaT += tNow - tOld 
#                 tOld = tNow    

#                print("pushed",end='.')
                    
                

                base += 24
#            print("countRawLen", len(countRaw))#print('rxm-tm', NEvents0,NEvents1,count)
          # ---------- TIM-TM2 ----------
        elif (cls, msg) == TIM_TM2:
            #print('5 readData free mem:',gc.mem_free())

            #print('TIM_TM2')
            ch = plb[0]
            edgeInfo = plb[1]

            edgeF     = (edgeInfo >> 2) & 1
            edgeR     = (edgeInfo >> 7) & 1
            timeValid = (edgeInfo >> 6) & 1

            count = plb[2] | (plb[3] << 8)
            wnoR  = plb[4] | (plb[5] << 8)
            wnoF  = plb[6] | (plb[7] << 8)

            towMsR = (
                plb[8] |
                (plb[9] << 8) |
                (plb[10] << 16) |
                (plb[11] << 24)
            )

            towSubMsR = (
                plb[12] |
                (plb[13] << 8) |
                (plb[14] << 16) |
                (plb[15] << 24)
            )

            towMsF = (
                plb[16] |
                (plb[17] << 8) |
                (plb[18] << 16) |
                (plb[19] << 24)
            )

            towSubMsF = (
                plb[20] |
                (plb[21] << 8) |
                (plb[22] << 16) |
                (plb[23] << 24)
            )

            accEst = (
                plb[24] |
                (plb[25] << 8) |
                (plb[26] << 16) |
                (plb[27] << 24)
            )

            if det == 1:
                #print('TIM-TM',count)
                dtMs=towMsR-oldtowMsR
                if (dtMs)>75:
                    #countdtMs += 1
                    print ("count, toMsR, oldtowMsR, dt", count, towMsR, oldtowMsR,dtMs)
                oldtowMsR=towMsR
                push_all_cal(wno= wnoR, ms= towMsR, sub= towSubMsR, count = count)

#                 countCal.append(count)
#                 towMsCal.append(towMsR)
#                 towSubMsCal.append(towSubMsR)
                #print('6 readData free mem:',gc.mem_free())

                return (wnoR, towMsR, towSubMsR, timeValid)

            return [
                (0, 1, ch, wnoR, towMsR, towSubMsR),
                (1, 1, ch, wnoF, towMsF, towSubMsF)
            ]

        # ---------- NAV-CLOCK ----------
        elif (cls, msg) == NAV_CLOCK:
            #print('7 readData free mem:',gc.mem_free())

            #print('NAV_CLOCK')
            iTOW = (
                plb[0] |
                (plb[1] << 8) |
                (plb[2] << 16) |
                (plb[3] << 24)
            )

            iclkBias  = ustruct.unpack_from('<i', plb, 4)[0]
            iclkDrift = ustruct.unpack_from('<i', plb, 8)[0]

            tAcc = (
                plb[12] |
                (plb[13] << 8) |
                (plb[14] << 16) |
                (plb[15] << 24)
            )

            fAcc = (
                plb[16] |
                (plb[17] << 8) |
                (plb[18] << 16) |
                (plb[19] << 24)
            )

            slope = iclkDrift
            #print('** slope =', slope)
            #print('1 readData free mem:',gc.mem_free())

        # Yield once after heavy UART work
        time.sleep_ms(0)
        #print("return (0,0,0,0)")
        return (0, 0, 0, 0)

    #except Exception as e:
        print("Error in readData:", e)
        return (0, 0, 0, 0)


    


# @micropython.native
# def push_all_raw(rf: int, ch: int, wno: int, ms: int, sub: int, count: int):
#     pos = raw_write_idx[0]
#     buf_rf    = rb_raw_rf.buffer
#     buf_ch    = rb_raw_ch.buffer
#     buf_count = rb_raw_count.buffer
#     buf_wno    = rb_raw_wno.buffer
#     buf_ms    = rb_raw_ms.buffer
#     buf_sub   = rb_raw_sub.buffer
#     buf_rf[pos]    = rf
#     buf_ch[pos]    = ch
#     buf_count[pos] = count
#     buf_wno[pos]   = wno
#     buf_ms[pos]    = ms
#     buf_sub[pos]   = sub
#     raw_write_idx[0] = (pos + 1) % CAPACITY_RAW
#     if raw_count[0] < CAPACITY_RAW:
#         raw_count[0] += 1
# 
# 
# @micropython.native
# #def push_all_cal(rf: int, ch: int, wno: int, ms: int, sub: int, count: int):
# def push_all_cal(wno: int, ms: int, sub: int, count: int):
#     pos = cal_write_idx[0]
# #     buf_rf    = rb_cal_rf.buffer
# #     buf_ch    = rb_cal_ch.buffer
#     buf_count = rb_cal_count.buffer
#     buf_wno    = rb_cal_wno.buffer
#     buf_ms    = rb_cal_ms.buffer
#     buf_sub   = rb_cal_sub.buffer
# #     buf_rf[pos]    = rf
# #     buf_ch[pos]    = ch
#     buf_count[pos] = count
#     buf_wno[pos]   = wno
#     buf_ms[pos]    = ms
#     buf_sub[pos]   = sub
#     cal_write_idx[0] = (pos + 1) % CAPACITY_CAL
#     if cal_count[0] < CAPACITY_CAL:
#         cal_count[0] += 1
# 
#     

# ---------- Main Loop ----------

if con_to_wifi(ssid, password):
#    _thread.start_new_thread(start_listener, ())
    print("No OTA listener started in background.")
else:
    print("Wi-fi connection failed.")
ip, subnet, gateway, dns = wlan.ifconfig()
ip_last_byte = int(ip.split('.')[-1])           # NEED TO PRINT THE ENTIRE IP ADDRESS HERE?
print("ESP IP:", ip_last_byte)
print(type(ip_last_byte))
print(ip)

s = connect_socket(HOST,PORT)
time.sleep(2)
#s.setblocking(False) #SOme blocking may be good. I want the code to wait for data, but not to wait when sending. Maybe there is a good medium here.
s.settimeout(.1)

send_packet_format = "!iiiiiiiiii"
request_packet_format = '!iiiii'


NEvents0 = 0
NEvents1 = 0
deltaT = 0
time.sleep(1)
clearRxBuf()
clear_wifi_rx_buffer(s)
# RFRaw=[]
# chRaw=[]
# countRaw=[]
# countCal=[]
# towMsRaw=[]
# towMsCal=[]
# towSubMsRaw=[]
# towSubMsCal=[]
uart1.write(POLL_NAV_CLOCK) #Poll Nav Clock
slope=0
tRaw1=None
tCal1 = None
Valid = 0
res=None
oldtowMsR = 0            
oldtowMs = 0            
countdtMs = 0            
                    
#initialise Valid, slope  and offset 
while ((slope == 0) or (tRaw1 == None) or (Valid == 0)):
    print('\ninit while loop', slope, tRaw1, Valid, res)
    uart1.write(POLL_NAV_CLOCK) #Poll Nav Clock
    for i in range(4):
        print(i,end='.')
        res=readData(1)
        print('r',end = '.')
        if (res[1] > 0):
            print('i',end='.')
            if (res[3] > 0):
                print('>',end='.')
                Valid = 1
            else:
                Valid = 0
                print("GPS not locked")
                time.sleep(1)# wait 1 second before trying again
                break

        lastCount=rb_cal_count.get(0)  #latest cal count
        #Calibration
        #print(rb_cal_count.buffer[0:5])
        #print(rb_raw_count.buffer[0:50])
              
        for i in range(raw_count[0]):
            if rb_raw_count.get(i)==lastCount:
                tCal1=rb_cal_ms.get(0)*1000000+(rb_cal_sub.get(0))
                tRaw1=rb_raw_ms.get(i)*1000000+(rb_raw_sub.get(i)//1000)
                break

#     for i in range(lastR,-1,-1):
#         print('line 749')
#         if countRaw[i]==countCal[lastC]:
#             #print("i:", i)
#             #print("countRaw[i]:", countRaw[i])
#             #print("countCal[lastC]:", countCal[lastC])
#             
#             tCal1=towMsCal[lastC]*1000000+(towSubMsCal[lastC])
#             tRaw1=towMsRaw[i]*1000000+int(towSubMsRaw[i]/1000)
#             break
    
clearRxBuf()
# 5 seconds
#print("Running")
gc.collect()
print("free mem4", gc.mem_free())

error_msg = (100, mac_id, 15, time.ticks_ms(), ip_last_byte, 0, 0, 0, 0, 0) # This tells me when the board restarted how long it took to reach the main loop since booting
packet = data_packing(send_packet_format, error_msg)
s.send(packet)

#deltaT1 = 0
T0=time.ticks_us()
T1=0
NEventsSent0=0
NEventsSent1=0
T0=time.ticks_us()
# RFRaw=[]
# chRaw=[]
# countRaw=[]
# countCal=[]
# towMsRaw=[]
# towMsCal=[]
# towSubMsRaw=[]
# towSubMsCal=[]

array_count = 0
Rate0=0
Rate1=0
R0index=[]
R1index=[]
CC=0
reqCount=0
#tWhile0=time.time_ns()//1000000
global toi_len

t=array.array("I",bytearray(2048))
tIdx=0
sentTime=0
while True:
    print('buffer size ',uart1.any(), 'bytes')

    #whileTime=time.time_ns()//1000
    #print(whileTime, sentTime, whileTime - sentTime)
    t[tIdx]=time.time_ns()
    tIdx += 1
#    try:
    if True:       # Ensure Wi-Fi stays connected
        if not wlan.isconnected():
            print("Wi-Fi disconnected. Reconnecting...")
            con_to_wifi(ssid, password)
        maxRxBuf(15000) #Make sure buffer isnt full before recieving
        try:
#             t[tIdx]=time.time_ns()//1000
#             tIdx += 1
#            print('buffer size ',uart1.any(), 'bytes\n')
            #print("2")
            pass
            #req = s.recv(20) #Dont need poller, can just check for socket activity on a not blocking socket
            #print("Data received:", len(req))
            #print('buffer size ',uart1.any(), 'bytes\n')

        except Exception:
            print("Error receiving")
            #error_msg = (100, mac_id, 11, 0, 0, 0, 0, 0, 0, 0)
            #packet = data_packing(send_packet_format, error_msg)
            #s = reconnect_socket(s)
            #s.send(packet)

            continue
        if True:
#        if req:
            try:
                #inst, w_num, ms, sub_ms, event_num = ustruct.unpack(request_packet_format, req) #There might be an error here. What if multiple messages came in at the same time and I read them all at the same time? Will they be lost as ustruct may only evaluate the first little bit?
                inst=99
                event_num=99
                #print("3")
            except Exception as e:

                print("Error unpacking request:", e)
                error_msg = (100, mac_id, 12, 0, 0, 0, 0, 0, 0, 0)
                packet = data_packing(send_packet_format, error_msg)
                s.send(packet)
                continue

            if inst == 99:
#                 RFRaw=RFRaw[-250:]
#                 chRaw=chRaw[-250:]
#                 countRaw=countRaw[-250:]
#                 countCal=countCal[-20:]
#                 towMsRaw=towMsRaw[-250:]
#                 towMsCal=towMsCal[-20:]
#                 towSubMsRaw=towSubMsRaw[-250:]
#                 towSubMsCal=towSubMsCal[-20:]
                

                #print("GPS request...")
                #print('buffer size ',uart1.any(), 'bytes\n')
                #print('free mem before request:', gc.mem_free())
#                timesOfInterest = request(-1,100,0)
                #print("count_Len",raw_count[0],cal_count[0])
                #time.sleep_ms(150)
                t[tIdx]=time.time_ns()//1000
                tIdx += 1

                if raw_count[0] > 0:
                    #print("CC",CC)
                    if CC == 0:
                        #print("request(-1,-2000,0)")
                        RF,cal,ch,w_num,ms,sub_ms = request(-1,-2000,0)
                    else:
                        #timeReq=uart1.any()//40
                        #print("request(-1,",200,",0)")
                        RF,cal,ch,w_num,ms,sub_ms = request(-1,250,0)
                    CC = (CC+1)%2


                else:
                    RF,cal,ch,w_num,ms,sub_ms = request(-1,100,0)
                reqCount += 1
                t[tIdx]=time.time_ns()//1000
                tIdx += 1
                #print('free mem after request:', gc.mem_free())
#                timesOfInterest = request(w_num, ms, sub_ms)
                #print("4")
                if RF is None or len(RF)==0:
                    msg = (99, mac_id, 0, 0, 0, 0, 0, 0, event_num, array_count)


                    packet = data_packing(send_packet_format, msg)
                    try:
                        pass
                        #s.send(packet)
                    except Exception as e:
                        #print("send error",e)
                        s = reconnect_socket(s)
                    array_count+=1
                    wdt.feed()
                    continue
                
                #print(timesOfInterest)
                #print('free mem before for loop:', gc.mem_free())

                #print("7")
#                rf,cal,ch,wno,ms,subms
                #print("len(RF)",len(RF))
#                 t[tIdx]=time.time_ns()//1000
#                 tIdx += 1
                #print("tIdx",tIdx)

                for i in range(toi_len):
#                     inst = 99           
#                     ID = mac_id
#                     RF = timesOfInterest[i][0]              
#                     cal = timesOfInterest[i][1]               
#                     ch = timesOfInterest[i][2]           
#                     w_num = timesOfInterest[i][3]   
#                     ms = timesOfInterest[i][4]      
#                     sub_ms = timesOfInterest[i][5]
#                     event_num = event_num #Unnecessary
                    count = array_count #timesOfInterest[i][6]
                    
                    msg = (99, mac_id, RF[i], cal[i], ch[i], w_num[i], ms[i], sub_ms[i], event_num, count)
#                    msg = (inst, ID, RF, cal, ch, w_num, ms, sub_ms, event_num, count)
                    #print(msg)
                    packet = data_packing(send_packet_format, msg)
                    #print("5")
                    try:
                        if (RF[i]==0)& (ch[i]== 0):  #&(random.randint(0,10)==1):
                            #s.send(packet) #Should I start checking wifi and socket are active before sending? It seems kind of pointless,
                                            #I would have to reconnect to them anyway if it I wasnt and w
                            #print("sent packet")
                            #array_count+=1
                            if RF[i]==0:
                                if ch[i]==0:
                                    NEventsSent0 +=1
                                if ch[i]==1:
                                    NEventsSent1 +=1
                        #NEvents2+=1
                        wdt.feed()
                        #print('buffer size ',uart1.any(), 'bytes\n')
                        #print("data sent")
                        #print('Rates:',NEvents0, deltaT, NEvents0/deltaT*1000)

                        #print("6")
                    except Exception as e:
                        print("Send error2:", e)
                        error_msg = (100, mac_id, 13, 0, 0, 0, 0, 0, 0, 0)
                        packet = data_packing(send_packet_format, error_msg)
                        s = reconnect_socket(s)
                        s.send(packet)

                        break  # Exit inner loop
                t[tIdx]=time.time_ns()//1000
                tIdx += 1

                #print('free mem after for loop:', gc.mem_free())

                #R0index=[]
                #R1index=[]
#                 for i in range(len(RFRaw)):
#                     if RFRaw[i] == 0:
#                         if chRaw[i] == 0 :
#                             Nevents0 += 1
#                             #R0index.append(i)
#                         elif chRaw[i] ==1:
#                             Nevents0 += 1
# 
#                 #print('endfor')
#                 length0=len(R0index)
#                 length1=len(R1index)
#                 print('length', length0,length1, len(towMsRaw))
#                 
#                 if length0 > 1:
#                     R0indexF=R0index[0]
#                     R0indexL=R0index[-1]
#                     #print(R0index)
#                     print(R0indexF, R0indexL)
#                     
#                     timeElapsed0=(towMsRaw[R0indexL] - towMsRaw[R0indexF])*1000000 + int((towSubMsRaw[R0indexL] - towSubMsRaw[R0indexF])/1000)
#                     print(timeElapsed0)
#                     NEvents0 += length0-1
#                     deltaT0 += timeElapsed0
#                     print(NEvents0,deltaT0)
#                 if length1 > 1:
#                     R1indexF=R1index[0]
#                     R1indexL=R1index[-1]
#                     #print(R1index)
#                     #print(R1indexF, R1indexL)
#                     print(R1indexF, R1indexL)
#                     timeElapsed1=(towMsRaw[R1indexL] - towMsRaw[R1indexF])*1000000 + int((towSubMsRaw[R1indexL] - towSubMsRaw[R1indexF])/1000)
#                     print(timeElapsed1)
#                     NEvents1 += length1-1
#                     deltaT1 += timeElapsed1
#                     print(NEvents1,deltaT1)
#                     T1=time.ticks_us()
                #print('free mem after for loop2:', gc.mem_free())
                T1=time.ticks_us()
            
                if T1-T0 > 5000000:
                    print('NEvents')
#                    T1=time.ticks_us()
                    uart1.write(POLL_NAV_CLOCK)
                    Rate0 = round((NEvents0*1000)/(deltaT+1e-9))
#                     Rate1 = round((NEvents1*1000000000)/(deltaT1+1e-9))
#                     RateSent0 = round(NEventsSent0*1000000/(T1-T0)*1000)
#                     RateSent1 = round(NEventsSent1*1000000/(T1-T0)*1000)
                    print('*Rate0:',NEvents0, deltaT, Rate0)
                    print("requests", reqCount, reqCount/deltaT*1000)
                    reqCount=0
#                     print('*Rate1:',Rate1)
#                     print('*RateSent0:',RateSent0)
#                     print('*RateSent1:',RateSent1)
                    #exit()
                    #Rate Code; Mac ID; Number Ch0; Number Ch1; Time in ms; W#; MS; Subms; Null Count; Unreasonable Request Count)
                    #wno, Ms, subMs = rtc_to_gps_wno_ms_subms()
                    msg = (98, mac_id, NEvents0, NEvents1, deltaT, 0, 0, 0, 0, 0)
#                    msg = (99, mac_id, 19, Rate0+Rate1, RateSent0+RateSent1, 0, 0, 0, 0, 0)
                    rate_packet = data_packing(send_packet_format, msg)
                    NEvents0 =NEvents1=NEventsSent0=NEventsSent1=deltaT=0
                    T0=T1
                    try:
                        print("s.send")
                        #s.send(rate_packet)
                       # print("data sent")
                        wdt.feed()
                        print('buffer size ',uart1.any(), 'bytes')

                        print("data sent\n")
                        sentTime=time.time_ns()//1000
#                         for i in range(50):
#                             print(i+1, t[i+1]-t[i])
                            
                        tIdx=0
                    except Exception as e:
                        print("error in rate calc",e)
                        s = reconnect_socket(s)
                        #break  # Exit inner loop
                        continue

#     except Exception as e:
#         print("Main loop exception:", e)
#         exit()
#         error_msg = (100, mac_id, 14, 0, 0, 0, 0, 0, 0, 0)
#         packet = data_packing(send_packet_format, error_msg)
#         s.send(packet)
#         print("Error sent")
#         continue

        
        


