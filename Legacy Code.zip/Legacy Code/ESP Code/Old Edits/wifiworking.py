import socket
import time
import network
import time

ssid = 'ONet_EXT'
password = ''
wlan = network.WLAN(network.STA_IF)
#wlan.disconnect()
time.sleep(.1)
wlan.active(False)
time.sleep(1)
wlan.active(True)
time.sleep(1)
#wlan.ifconfig(('10.0.0.7', '255.255.255.0', '10.0.0.1', '10.0.0.1'))  # Example; use a free IP, correct subnet/gateway/DNS
wlan.connect(ssid, password)

for _ in range(30):  # ~10 seconds
    status = wlan.status()
    print("status:", status)
    if status == network.STAT_GOT_IP:
        break
    time.sleep(0.5)

if wlan.isconnected():
    print("Connected!")
    print("IP:", wlan.ifconfig()[0])
else:
    print("WiFi failed, final status:", wlan.status())

def tcp_ping(host, port=80, timeout=1):
    try:
        s = socket.socket()
        s.settimeout(timeout)
        s.connect((host, port))
        s.close()
        return True
    except:
        return False

ip, subnet, gateway, dns = wlan.ifconfig()
print(ip,subnet,gateway,dns)
print(tcp_ping(ip))
print(tcp_ping('169.254.241.88',12345))
print(tcp_ping('134.69.218.243',12345))
print(tcp_ping('10.0.0.6',12345))