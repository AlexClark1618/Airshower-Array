import socket
import select
import struct
import os
import re
from datetime import datetime, timedelta
import gzip
import shutil
import time
import traceback
import errno

#Changelog:
    #11/14/25- Added socket cleanup function to remove deadsockets
    #Better handled nonblocking send and receive functions with appropriate error catching. SHould hopefully reduce errors.
    #Borehole and veto are broadcasting to eachother filling up TCP socket. Added a recv in each esp code to clear the buffer. Too complicated (as I see) to try and deal with it server side.

HOST = '0.0.0.0'
PORT = 12345

# Data Format: 
PACKET_FORMAT = "!iiiiiiiiii"
PACKET_SIZE = struct.calcsize(PACKET_FORMAT)

class RotatingFileWriter:
    def __init__(self, base_name="output", ext=".txt", time_length = 1, gzip_files=False, header = ""):
        self.base_name = base_name
        self.ext = ext
        self.time_length = time_length
        self.gzip_files = gzip_files
        self.date = datetime.now().strftime("%Y%m%d")
        self.run_number = self._get_next_run_number()
        self.cycle_number = 1
        
        self.header = header
        self.open_new_file()

    def _get_next_run_number(self):
        """Find the next available run number across all files."""
        run_pattern = re.compile(
            rf"{self.base_name}_(\d+)_run(\d+)_cycle\d+{self.ext}$"
        )
        max_run = 0
        for fname in os.listdir("."):
            match = run_pattern.match(fname)
            if match:
                run_num = int(match.group(2))
                max_run = max(max_run, run_num)
        return max_run + 1

    def open_new_file(self):
        if hasattr(self, "file") and self.file:
            self._close_and_gzip()
        self.filename = (
            f"{self.base_name}_{self.date}_run0{self.run_number}_cycle00{self.cycle_number}{self.ext}"
        )
        self.file = open(self.filename, "w", buffering = 1)#buffering=1024*1024)
        self.start_time = datetime.now()

        if self.header:
            self.file.write(self.header + "\n") 

        print(f"[INFO] Opened {self.filename}")
        self.cycle_number += 1
        time.sleep(1)

    def _close_and_gzip(self):
        """Close the current file and optionally gzip it."""
        self.file.close()
        if self.gzip_files:
            gz_filename = self.filename + ".gz"
            with open(self.filename, 'rb') as f_in, gzip.open(gz_filename, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
            os.remove(self.filename)  # remove original uncompressed file
            print(f"[INFO] Compressed {self.filename} -> {gz_filename}")

    def write(self, data: str):
        
        if datetime.now() - self.start_time >= timedelta(hours = self.time_length):
            self.open_new_file()

        self.file.write(data)
        #print(self.current_size)

    def close(self):
        if self.file:
            self._close_and_gzip()

def cleanup_client_socket(sock, addr, sockets, clients):
    if sock in sockets:
        sockets.remove(sock)
    if sock in clients:
        del clients[sock]
    sock.close()
    with open(connection_log, 'a') as log:
        log.write(f"{time.time()}: Disconnected from {addr}\n")
    print(f"[SERVER] Dead client socket removed: {addr}")

def run_server():

    #Info Logs
    with open(connection_log, 'a') as log:
        log.write(f"\n--- Restart at {datetime.now()} ---\n")

    with open(error_log, 'a') as log:
        log.write(f"\n--- Restart at {datetime.now()} ---\n")

    with open(unique_esp_log, 'a') as log:
        log.write(f"\n--- Restart at {datetime.now()} ---\n")

    # Create the server socket
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    server.setblocking(False)

    print(f"[SERVER] Server listening on {HOST}:{PORT}")

    sockets = [server]  # includes all connected sockets
    clients = {}        # map client socket -> {'buffer': bytearray, 'id': int}

    last_time = 0
    esp_unique_ID_list = []


    while True:

        if int(time.time())%60==0 and int(time.time())!=last_time: #To let you know server is running
            print(".")
            last_time = int(time.time())

        readable, _, _ = select.select(sockets, [], [], 0.1)

        for s in readable:
            if s is server: #Deals with server connects to client sockets
                try:
                    client_socket, addr = server.accept()
                    time.sleep(0.1)
                    client_socket.setblocking(False)
                    sockets.append(client_socket)
                    clients[client_socket] = { #Dictionary of client raw data and addresses
                        "buffer": bytearray(),
                        "addr": addr
                    }
                    print(f"[SERVER] New ESP32 connected from {addr}")
                    with open(connection_log, 'a') as log:
                        log.write(f"{time.time()}: Reconnected from {addr}\n")

                except OSError as e:
                    if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        # No client to accept right now, ignore
                        continue
                    else:
                        print(f"[SERVER] Error accepting connection: {addr}; {e}")
                        with open(error_log, 'a') as f:
                            f.write(f"[SERVER] Error accepting connection: {addr}; {e}\n")
                        continue

            else: #Reads client data
                client_info = clients.get(s)
                client_addr = client_info["addr"] if client_info else None
                try:
                    data = s.recv(1024)
                    if not data:  # empty = client closed connection
                        cleanup_client_socket(s, client_addr, sockets, clients)
                        continue

                except OSError as e:
                    if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        # Non-blocking socket has no data, this is fine
                        continue
                    else: #ETimedout isnt being used, ECONNRESET means client coneection was disconnected
                        print(f"[SERVER] Error Receiving from {client_addr}: {e}")
                        with open(error_log, 'a') as f:
                            f.write(f"[SERVER] Error Receiving from {client_addr}: {e}\n")

                        cleanup_client_socket(s, client_addr, sockets, clients)
                        continue

                clients[s]["buffer"].extend(data)

                # Packet buffer to handle multiple packets at the same time
                while len(clients[s]["buffer"]) >= PACKET_SIZE:
                    packet = clients[s]["buffer"][:PACKET_SIZE]
                    clients[s]["buffer"] = clients[s]["buffer"][PACKET_SIZE:]

                    #Unpacks data
                    inst, ID, RF, Cal, ch, w_num, ms, sub_ms, event_num, count = struct.unpack(PACKET_FORMAT, packet)

                    if inst == 1: #Info Code
                        with open(connection_log, 'a') as log:
                            log.write(f"{inst}; {ID}; {RF}; {Cal}; {ch}; {w_num}; {ms}; {sub_ms}; {event_num}; {count}\n")

                    
                    elif inst == 100: #Error code
                        #writer.write(f"{inst}; {ID}; {RF}; {Cal}; {ch}; {w_num}; {ms}; {sub_ms}; {event_num}; {count}\n")
                        with open(error_log, 'a') as f:
                            f.write(f"[ESP]:{inst}; {ID}; {RF}; {Cal}; {ch}; {w_num}; {ms}; {sub_ms}; {event_num}; {count}\n") # Ignore labels; RF = Error Code"""
                    

                    elif inst == 99: #Data Code
                        if ID not in esp_unique_ID_list:
                            esp_unique_ID_list.append(ID)
                            with open(unique_esp_log, 'a') as f:
                                f.write(f"{str(ID)}\n")

                        if ID == 48 or ID == 16:
                            writer.write(f"{inst}; {ID}; {RF}; {Cal}; {ch}; {w_num}; {ms}; {sub_ms}; {event_num}; {count}\n")
                            #print("BH data written to file")
                            
                            if ch == 0 and RF == 0: #Measuring time from rise                                
                                for client_sock in list(clients.keys()):
                                    if client_sock != s: #Broadcasts BH timestamp to all other clients except sender
                                        
                                        client_info = clients.get(client_sock)
                                        client_addr = client_info["addr"] if client_info else "Unknown"
                                        try:
                                            #time.sleep(0.1) #delay the broadcast by 100ms
                                            broadcast_format = '!iiiii'
                                            broadcast_packet = struct.pack(broadcast_format, inst, w_num, ms, sub_ms, event_num)
                                            broadcast = client_sock.send(broadcast_packet)
                                                                                                
                                            #print(f'Request for data sent:{broadcast}')
                    
                                        except OSError as e:
                                            if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                                                # Error can be skipped
                                                continue

                                            else:  # ECONNRESET or other fatal error
                                                print(f"[SERVER] Send Error to {client_addr}: {e}")
                                                with open(error_log, 'a') as f:
                                                    f.write(f"[SERVER] Send Error to {client_addr}: {e}\n")
                                                
                                                cleanup_client_socket(client_sock, client_addr, sockets, clients)
                                                continue

                        else: #For other clients
                            writer.write(f"{inst}; {ID}; {RF}; {Cal}; {ch}; {w_num}; {ms}; {sub_ms}; {event_num}; {count}\n")

                    else:
                        #writer.write("Unknown Code\n")
                        #    
                        with open(error_log, 'a') as f:
                            f.write(f"Unknown Code from client {client_addr}\n")

                        clients[s]["buffer"].clear()
                        print(f"Buffer cleared from client {client_addr}")

                        break

            

if __name__ == "__main__":

    try:
        while True:
            try:
                connection_log = 'connection_log.txt'
                error_log = 'error_log.txt'
                unique_esp_log = 'unique_esp_log.txt'
                HEADER = "Req Code; ID; RF; Cal; Ch, W#; t_ow mil; t_ow submil; Event"
                writer = RotatingFileWriter(base_name="gps_daq", ext=".txt", time_length = 1, header = HEADER) #1 hr long files
                run_server()

            except Exception as e: #Auto-restart server on any errors
                print(f"[FATAL ERROR] {e}")
                traceback.print_exc()
                with open(error_log, 'a') as f:
                    f.write(f"[SERVER] Fatal error: {e}\n{traceback.format_exc()}\n")
                
                writer.close()

                print("Restarting server in 3 seconds...")
                time.sleep(3)

    except KeyboardInterrupt:
        print("DAQ Stopped")
    #Note: Im noticing the esp keeps writting to the TCP buffer even after server shutdown, becasue Im not handling closing the sockets on shutdown.
    #May be something to worry about in the future, but right now its not a concern. I can probably just have a for loop through the clients list

    finally:
        writer.close()
