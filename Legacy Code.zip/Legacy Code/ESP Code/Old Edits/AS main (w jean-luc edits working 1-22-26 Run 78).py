#Airshower Main
#Updated- 10-28-25 (Sent from Jean-Luc)
#Updated with OTA- 11-10-25 (Sent from Tim)
#Updated 11/14/25 (Alex)

#Changelog
    #General clean up
    #Added send and receive functions
    #Reorganized Error codes. All having to do with wifi, sockets, and data packing cant send an error message back easily
    #Small logic changes in main loop

import socket
import ustruct
import time
import network
from machine import UART, Pin, WDT
import time
import gc
import ota_update
import _thread

#---------OTA Function------------
try:
    with open('config.txt') as f:
        detector_num = f.read().strip()
        print("This is Detector " + detector_num)
except OSError:
    detector_num = "0"  # default if not yet set
    print("No config.txt found, using default detector number:", detector_num)

version_num = "0.09"
# wdt = None
s = None
ota_in_progress = False

def start_listener():
    global wdt, s, ota_in_progress, version_num, detector_num
    addr = socket.getaddrinfo('0.0.0.0', 8080)[0][-1]
    t = socket.socket()
    t.bind(addr)
    t.listen(1)
    print("Listening for OTA trigger on port 8080...")

    while True:
        cl, addr = t.accept()
        print('Client connected from', addr)
        request = cl.recv(1024)
        if not request:
            cl.close()
            continue

        #request = str(request)
        request = request.decode()

        if "/ota" in request:
            print("OTA trigger received")
            try:
                #wdt = WDT(1000000)  # effectively disables watchdog during OTA
                print("Watchdog disabled for OTA.")
            except Exception as e:
                print("Error disabling WDT:", e)
            
            ota_in_progress = True
            time.sleep(0.2) # check this time for timeout errors in other places
            cl.send("HTTP/1.1 200 OK\r\n\r\nUpdating...\n")
            ota_update.download_and_install(cl)
        elif "/version" in request:
            cl.send("HTTP/1.1 200 OK\r\n\r\nDetector "+ detector_num + " Firmware Version Number: " + version_num + "\n")
        else:
            cl.send(b"HTTP/1.1 200 OK\r\n\r\nHello from ESP32\n")
        cl.close()


#---------GPS Variables-----------
UBX_HDR = b'\xb5\x62' # \xb5\x62
RXM_TM=b'\x02\x74'
TIM_TM2=b'\x0d\x03'
NAV_CLOCK=b'\x01\x22'
REQUESTED_TIME_WINDOW = 1000000  #returned times (ns) will be within +/- requested_time_window of time of interested 
# UBX poll message for NAV-CLOCK (class 0x01, ID 0x22)
POLL_NAV_CLOCK = b'\xb5\x62\x01\x22\x00\x00\x23\x6a'
uart1_tx_pin = 12  # Example: GPIO12
uart1_rx_pin = 14  # Example: GPIO14
rxbuf = (8192 * 3 ) # 24kB seems to be the max allowed within the code.
uart1 = UART(1, baudrate=115200*4, tx=Pin(uart1_tx_pin), rx=Pin(uart1_rx_pin), rxbuf=rxbuf)

time.sleep(0.1)
#NNC=10
numMeas=1

# ---------- Wi-Fi Setup ----------
ssid = 'AirShower2.4G'
password = 'Air$shower24'

wlan = network.WLAN(network.STA_IF)
wlan.active(True)

def clear_wifi_rx_buffer():  
    global s        
    if not s:
        print("No socket to clear.") 

    try:
        data = s.recv(1024)
     
        print("Wifi RX buffer cleared of:", len(data), "bytes")
    except Exception as e:
        print("Error during buffer clear:", e)

def con_to_wifi(ssid, password):
    if wlan.isconnected():
        wlan.disconnect()
        time.sleep(0.1)
    
    while not wlan.isconnected():
        try:
            print("Connecting to Wi-Fi...")
            wlan.connect(ssid, password)
            time.sleep(0.1)
            while not wlan.isconnected():
                time.sleep(0.1)
            print("Wi-Fi connected.")
            return wlan.ifconfig()
        except Exception as e:
            print(f"Wifi connection attempt failed: {e}")

if con_to_wifi(ssid, password):
    _thread.start_new_thread(start_listener, ())
    print("OTA listener started in background.")           

# ---------- Wifi and Socket Variables -----------
mac_id = wlan.config('mac')[-1]  # last byte of MAC
print('mac id:', mac_id)
ip, subnet, gateway, dns = wlan.ifconfig()
ip_last_byte = int(ip.split('.')[-1])
print("ESP IP:", ip_last_byte)

HOST = '134.69.77.61' #Karbon Computer
PORT = 12345

wdt = WDT(timeout=20000) # extra 0

# ---------- Socket Functions ----------
def connect_socket(host, port):
    while True:
        try:
            s = socket.socket()
            s.connect((host, port))
            print("Socket connected.")
            return s
        except Exception as e:
            print("Failed to connect socket:", e)
            #Cant send error to server without socket connection
            time.sleep(0.1)

def reconnect_socket(sock):
    try:
        if sock:
            sock.close()
    except Exception as e:
        print("Error closing socket:", e)

    time.sleep(0.1)
    return connect_socket(HOST, PORT)

s = connect_socket(HOST,PORT)
#s.setblocking(False)
s.settimeout(.05)

# ---------- Send and Receive Functions -----------
def send_data(d):
    global s
    while True:
        try:
        
            return s.send(d)

        except OSError as e:
            if e.args[0] in [11, 110, 104]:  # EAGAIN, ETIMEDOUT, ECONNRESET
                print("No data to send")
                return None
            else:
                print("Send error:", e)
                error_msg = (100, mac_id, 2, 0, 0, 0, 0, 0, 0, 0)
                packet = data_packing(send_packet_format, error_msg)
                #send_data(packet)
                s = reconnect_socket(s)  
                return None

def recieve(num_bytes):
    global s
    while True:
        try:
            maxRxBuf(10000)
 
            return s.recv(num_bytes)
        
        except OSError as e:
            if e.args[0] in [11, 110, 104]:  # EAGAIN, ETIMEDOUT, ECONNRESET
                print("No data to receive")
                return None
            else:
                print("Receive error:", e)
                error_msg = (100, mac_id, 3, 0, 0, 0, 0, 0, 0, 0)
                packet = data_packing(send_packet_format, error_msg)
                send_data(packet)
                s = reconnect_socket(s)  
                return None

# ---------- Data Packing -----------
send_packet_format = "!iiiiiiiiii"
request_packet_format = '!iiiii'

def data_packing(packet_format: str, msg: tuple):
    try:
        packet = ustruct.pack(packet_format, 
            msg[0],#inst,            # char (1 byte)
            msg[1],#ID,
            msg[2],#RF,              # char (1 byte)
            msg[3],#cal,              # uint8 (1 byte)
            msg[4],#ch,          # uint8 (1 byte)
            msg[5],#w_num,      	 # uint32 (4 bytes) #Q for 8 byte uint64
            msg[6],#ms,         # uint32 (4 bytes)
            msg[7],#sub_ms,
            msg[8],#event_num                  # uint32 (4 bytes)
            msg[9] #count
        )
        
        return packet
    except Exception as e:
        print("Error in data packing", {e})
        #Cant send to server if error need data packing

# ---------- GPS Functions ----------
def clearRxBuf():
    print('clearRxBuf')

    global RFRaw, chRaw, countRaw, countCal, towMsRaw, towMsCal,towSubMsRaw, towSubMsCal

    try:
        while uart1.any():
            #print('buffer cleared of ',uart1.any(), 'bytes\n')
            (uart1.read())
        RFRaw=chRaw=countRaw=countCal=towMsRaw=towMsCal=towSubMsRaw=towSubMsCal=[]
    except Exception as e:
        print("Error in clear buffer:", {e})

def maxRxBuf(n):
    global RFRaw, chRaw, countRaw, countCal, towMsRaw, towMsCal,towSubMsRaw, towSubMsCal
    print('maxRxBuf')
    try:
        while (uart1.any() > (n )):
            nskim = uart1.any()-n + 1000
            print('buffer cleared of ',nskim, 'bytes\n')
            (uart1.read(nskim))
        RFRaw=chRaw=countRaw=countCal=towMsRaw=towMsCal=towSubMsRaw=towSubMsCal=[]
    except Exception as e:
        print('maxRxbuf exception',e)
        error_msg = (100, mac_id, 2, 0, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        s.send(packet)

def findUBX_HDR():
    try:
        #print('findUBX_HDR')
        Byte2=0
        while Byte2 != b'\x62':
            while uart1.any() < 1:
                time.sleep_ms(0)
                pass
            Byte1 = uart1.read(1)
            while Byte1 != b'\xb5':
                #print('.',end='')
                while uart1.any() < 1:
                    time.sleep_ms(0)
                    pass
                Byte1 = uart1.read(1)
                time.sleep_ms(0)
                pass
            #print('')
            while uart1.any() < 1:
                time.sleep_ms(0)
                pass
            Byte2=uart1.read(1)
            
    except Exception:
        print("findUBX_HDR error:",e)
        error_msg = (100, mac_id, 5, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        send_data(packet)

def findHDR2():
    while uart1.any() < 4:
        time.sleep_ms(0)
        pass
    data0 = uart1.read(4)
    #print('Header: ',data0)
    bytehdr2 = data0[0:2]
    lenb = data0[2:4]
    leni = int.from_bytes(lenb, "little")
    return(bytehdr2, leni)

'''
def request(wnoToi,MsToi,subMsToi):
    try:
        resToi=MsToi*1000000+subMsToi
        gc.collect()
        res=(0,0,0,0)
        #print("res[1]", res[1])
        #print("Ms:", MsToi)
        #print("request started")
        while res[1] < MsToi: #Exceed the time of interest by at least 1 ms    
            res=readData(1)
            #print('buffer size ',uart1.any(), 'bytes\n')

            #print("res complete")
            if res[0] != 0:
                #print(res[0] == 0)
                #print ('read Cal Data',res)
                diff = MsToi - res[1]
                if (abs(diff) > 2000) | (res[0] != wnoToi) :
                    print('Unreasonable request')
                    #print("Deltat:", diff)
                    #print("Deltat:", MsToi - res[1])
                    #print('Unreasonable request')
                    error_msg = (100, mac_id, 16, diff, 0, 0, 0, 0, 0, 0)
                    packet = data_packing(send_packet_format, error_msg)
                    send_data(packet) 
                
        readData(1)
        timeValid = res[3]
        lastC=len(countCal)-1
        lastR=len(countRaw)-1
        #Find upper index in raw data
        #print("countRaw:", countRaw)
        #print("countCal:", countCal)
        ##print("lastR:",lastR)
        #print("lastC:",lastC)
        #print("towMsRaw:",towMsRaw[-60:])
        #print("towMsCal:", towMsCal)
        #print('buffer size ',uart1.any(), 'bytes\n')

        if (lastC < 1) or (lastR < 1): #Bandaid for when there is only one calibrated data for some reason
            print('Too few elements')
            error_msg = (100, mac_id, 18, 0, 0, 0, 0, 0, 0, 0)
            packet = data_packing(send_packet_format, error_msg)
            send_data(packet)
            return None
        
        
        rawIndex2 = None
        rawIndex1 = None


        for i in range(lastR,-1,-1):
            if countRaw[i]==countCal[lastC]:
                #print("i:", i)
                #print("countRaw[i]:", countRaw[i])
                #print("countCal[lastC]:", countCal[lastC])
                rawIndex2=i
                break
        #print("rawIndex2:",rawIndex2)
        #Find lower index in raw data
        for i in range(lastR-1,-1,-1):
            if countRaw[i]==countCal[lastC-1]:
                #print("i:", i)
                #print("countRaw[i]:", countRaw[i])
                #print("countCal[lastC-1]:", countCal[lastC-1])

                rawIndex1=i
                break
        #print("rawIndex1:",rawIndex1)

        
        if rawIndex1 is None or rawIndex2 is None:
            print("!!!RawIndex None!!!")
            error_msg = (100, mac_id, 17, 0, 0, 0, 0, 0, 0, 0)
            packet = data_packing(send_packet_format, error_msg)
            send_data(packet)
            return None
        
        tCal2=towMsCal[lastC]*1000000+(towSubMsCal[lastC])
        tCal1=towMsCal[lastC-1]*1000000+(towSubMsCal[lastC-1])
        tRaw2=towMsRaw[rawIndex2]*1000000+int(towSubMsRaw[rawIndex2]/1000)
        tRaw1=towMsRaw[rawIndex1]*1000000+int(towSubMsRaw[rawIndex1]/1000)
        
        slope = (tCal2-tCal1)/(tRaw2-tRaw1)
        #print('slope', slope)
        #intercept = int(((tCal2-tRaw2)+(tCal1-tRaw1))/2)  # improved intercept
        timesOfInterest=[]
        for i in range(rawIndex1,rawIndex2+2):   #
            tRaw=towMsRaw[i]*1000000+int(towSubMsRaw[i]/1000)
    #       print(towMsRaw,towSubMsRaw,intercept,tRaw)
            res=int((tRaw-tRaw1)*slope)+tCal1
            #res=tRaw + intercept
            if ((abs(res-resToi))< 1000000):  #only keep cal data that are within 1ms of Toi.
                res2 = divmod(res, 1000000)
                #sec=int(res/1000000000)
                #ns=res-sec*1000000000
                #ms=int(ns/1000000)
                Ms=res2[0]
                SubMs=res2[1]
                if (SubMs > 999999):
                    print('*************SubMs > 999999*********')
                timesOfInterest.append((RFRaw[i],timeValid,chRaw[i],wnoToi,Ms,SubMs, countRaw[i])) 

        return(timesOfInterest)
    
    
    except Exception as e:
        print("Request error:", e)
        error_msg = (100, mac_id, 6, 0, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        send_data(packet)
        return None
'''

def request(wnoToi,MsToi,subMsToi):
    global slope
    global RFRaw, chRaw, countRaw, countCal, towMsRaw, towMsCal,towSubMsRaw, towSubMsCal

    try:
        print('100')
        res=(0,0,0,0)
        if (wnoToi == -1):
          #print('request(-1,0,0) called')
          while (res[0] == 0):
              #print('res[0] ==0')
              res=readData(1)
              #print('readData(1)')
          #print('res[1]:',res[1])
          MsToi = res[1]+MsToi
          subMsToi = res[2]
          #print('end if')
        resToi=MsToi*1000000+subMsToi
        gc.collect()
        print('free memory:',gc.mem_free())
        res=(0,0,0,0)
        #print("res[1]", res[1])
        #print("MsToi:", MsToi)
        print('101')
        #print("request started")
        diff=0
        while (diff < REQUESTED_TIME_WINDOW):  # | (bytehdr2 == RXM_TM): #Exceed the time of interest by at least 1 ms and capture an extra RXM data packet    
            res=readData(1)
            RFRaw=RFRaw[-95:]
            chRaw=chRaw[-95:]
            countRaw=countRaw[-95:]
            countCal=countCal[-2:]
            towMsRaw=towMsRaw[-95:]
            towMsCal=towMsCal[-2:]
            towSubMsRaw=towSubMsRaw[-95:]
            towSubMsCal=towSubMsCal[-2:]
            
            if res[1] > 0:
                diff=(res[1]-MsToi)*1000000+(res[2]-subMsToi)
                #print('while',diff,bytehdr2)
            #print('readData',time.time_ns())
            print('buffer size ',uart1.any(), 'bytes\n')

            #print("res complete")
            if res[0] != 0:
                if (abs(diff) > 1000000000) | ((res[0] != wnoToi) & (wnoToi != -1)) :
                    print('Unreasonable request', diff/1000000,'ms', res[1], MsToi)
                    error_msg = (100, mac_id, 16, diff, 0, 0, 0, 0, 0, 0)
                    packet = data_packing(send_packet_format, error_msg)
                    s.send(packet) 
#         print('102')                        
#         readData(1) #???
#         print('readData2',time.time_ns())
#         readData(1) #???
#         print('readData3',time.time_ns())
#         readData(1) #???
#         print('readData4',time.time_ns())
        timeValid = res[3]
        lastC=len(countCal)-1
        lastR=len(countRaw)-1
        #Find upper index in raw data
        #print("countRaw:", countRaw)
        #print("countCal:", countCal)
        #print("lastR:",lastR)
        #print("lastC:",lastC)
        #print("towMsRaw:",towMsRaw)
        #print("towMsCal:", towMsCal)
        #print('buffer size ',uart1.any(), 'bytes\n')
        print('103')

#         if (lastC < 0) or (lastR < 0): #Bandaid for when there is only one calibrated data for some reason
#             print('Missing elements')
#             error_msg = (100, mac_id, 18, 0, 0, 0, 0, 0, 0, 0)
#             packet = data_packing(send_packet_format, error_msg)
#             s.send(packet)
#             return None

        for i in range(lastR,-1,-1):
            if countRaw[i]==countCal[lastC]:
                #print("i:", i)
                #print("countRaw[i]:", countRaw[i])
                #print("countCal[lastC]:", countCal[lastC])
                #print("towMsCal[lastC]:", towMsCal[lastC])
                #print("towMsRaw[i]:", towMsRaw[i])
                #print("towSubMsRaw[i]:", towSubMsRaw[i])
                #print(lastC)
                #print(towSubMsCal)
                #print("towSubMsCal[lastC]:", towSubMsCal[lastC])
                
                
                tCal1=towMsCal[lastC]*1000000+(towSubMsCal[lastC])
                tRaw1=towMsRaw[i]*1000000+int(towSubMsRaw[i]/1000)
                break
        print('104')
        
        timesOfInterest=[]
        for i in range(len(towMsRaw)):   #
#             print('104.1')
            tRaw=towMsRaw[i]*1000000+int(towSubMsRaw[i]/1000)
#             print('104.2')
            
            res=(tRaw-tRaw1)-int((tRaw-tRaw1)*slope/1000000000)+tCal1
#             print('104.3')

            #print(f"i:{i},resToi:{resToi},tCal1:{tCal1}, tRaw1:{tRaw1}, tRaw:{tRaw}, res:{res}")
            #requested time window
            if ((abs(res-resToi))< REQUESTED_TIME_WINDOW):  #only keep cal data that are within 1ms of Toi.
                res2 = divmod(res, 1000000)
                Ms=res2[0]
                SubMs=res2[1]
                print(f"i:{i},resToi:{resToi},tCal1:{tCal1}, res:{res}, Ms:{Ms}, SubMs:{SubMs}")
                if (SubMs > 999999):
                    print('*************SubMs > 999999*********')
                timesOfInterest.append((RFRaw[i],timeValid,chRaw[i],wnoToi,Ms,SubMs, countRaw[i])) 
        print('105')          
        return(timesOfInterest)
    
    
    except Exception as e:
        print("Request error:", e)
        error_msg = (100, mac_id, 4, 0, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        s.send(packet)
        return None
'''
def readData(det):
    try:
    #det: 0 == BH and 1 == AS
    #     towMsR=0
    #     while towMsR < Request:
        
        #print('readData started')
        #maxRxBuf(15000)
        #if (nskim > 0):
        #    print('buffer cleared of ',nskim, 'bytes\n')
        findUBX_HDR()
        #print('found header')
        #print('\tFound UBX header: ', bytehdr)
        #bytehdr = UBX_HDR
        while uart1.any() < 4:
            pass
        data0 = uart1.read(4)
        #print('Header: ',data0)
        bytehdr2 = data0[0:2]
        lenb = data0[2:4]
        if bytehdr2 == RXM_TM:
            hdr2='RXM_TM'
            #print('1')
            #print('\tFound Raw time stamp header: ', bytehdr2)
        elif bytehdr2 == TIM_TM2:
            hdr2='TIM_TM2'
            #print('2')
            #print('\tFound Calibrated time stamp header: ', bytehdr2)

        leni = int.from_bytes(lenb, "little")
        #print('\tdata length: ',leni)
        ##print ('buffer ', uart1.any())

        while uart1.any() < (leni+2):
            if leni > rxbuf:
                maxRxBuf(15000)
                print("Buffer Cleared")
                return((0,0,0,0))

            #print('3')
            else:
                pass
        
        if (bytehdr2 == RXM_TM):
                plb = uart1.read(leni)
                #print(plb)
                cksum = uart1.read(2)
                #print('checksum:',cksum)
                version=plb[0]

                end="   "
                ##print('\nraw data:\n', bytehdr+bytehdr2+plb+cksum, '\n')

                ##print ('parsed data:')
                ##print(hdr+'|'+hdr2)
                #print('ver',version, end=end)
                numMeas=plb[1]
                #print('numMeas',numMeas, end ="\t")
                for ii in range(0, numMeas*24, 24):
                    #print('ii',ii,end=end)
                    edgeInfob=plb[8+ii:12+ii]
                    #print('edgeInfob',edgeInfob)
                    edgeInfo=int.from_bytes(edgeInfob, "little")
                    #print('edgeInfo',edgeInfo, end =end)
                    RF= (edgeInfo >> 4) & 1
                    #if RF ==1:
                        #print('EdgeF', end =end)
                    #else:
                        #print('EdgeR', end =end)
                    ch = edgeInfo & 1
                    ##print('channel ', ch, end =end)
                    countb = plb[12+ii:14+ii]
                    count=int.from_bytes(countb, "little")
                    ##print('count ', count, end =end)
                    wnob=plb[14+ii:16+ii]
                    wno=int.from_bytes(wnob,"little")
                    ##print('wno ', wno, end =end)
                    towMsb=plb[16+ii:20+ii]
                    towMs=int.from_bytes(towMsb,"little")
                    ##print('towMs ', towMs, end =end)
                    towSubMsb=plb[20+ii:24+ii]
                    towSubMs=int.from_bytes(towSubMsb,"little")
                    #print('towSubMs ', towSubMs)
                ##print('\n')
                    RFRaw.append(RF)
                    chRaw.append(ch)
                    countRaw.append(count)
                    towMsRaw.append(towMs)
                    towSubMsRaw.append(towSubMs)
                    #print('4')
        elif (bytehdr2 == TIM_TM2):
                plb = uart1.read(leni)
                #print(plb)
                cksum = uart1.read(2)
                #print('checksum:',cksum)

                end="   "
                ##print('\nraw data:\n', bytehdr+bytehdr2+plb+cksum, '\n')

                ##print ('parsed data:')
                ##print(hdr+'|'+hdr2)
                #print('ver',version, end=end)
                ch=plb[0]
                ##print('channel ',channel, end=end)
                edgeInfo=plb[1]
                #print('edgeInfo',edgeInfo, end = end)
                #edgeInfo=int.from_bytes(edgeInfob, "little")
                edgeF = (edgeInfo >> 2) & 1
                edgeR = (edgeInfo >> 7) & 1
                timeValid = (edgeInfo >> 6) & 1
                #timeValid = int.from_bytes(timeValidb, "little")
                ##print('timeValid', timeValid, end=end)
                countb = plb[2:4]
                count=int.from_bytes(countb, "little")
                ##print('count ', count, end =end)
                wnoRb = plb[4:6]
                wnoR=int.from_bytes(wnoRb, "little")
                ##print('wnoR ', wnoR, end =end)
                wnoFb = plb[6:8]
                wnoF=int.from_bytes(wnoFb, "little")
                ##print('wnoF ', wnoF, end =end)
                towMsRb=plb[8:12]
                towMsR=int.from_bytes(towMsRb,"little")
                ##print('towMsR ', towMsR, end=end)
                towSubMsRb=plb[12:16]
                towSubMsR=int.from_bytes(towSubMsRb,"little")
                ##print('towSubMsR ', towSubMsR, end=end)
                towMsFb=plb[16:20]
                towMsF=int.from_bytes(towMsFb,"little")
                ##print('towMsF ', towMsF, end=end)
                towSubMsFb=plb[20:24]
                towSubMsF=int.from_bytes(towSubMsFb,"little")
                ##print('towSubMsF ', towSubMsF, end=end)
                accEstb=plb[24:28]
                accEst=int.from_bytes(accEstb,"little")
                #print('accEst ', accEst, end=end)
                #print('5')
                ##print('\n')
                
                #cksum = uart1.read(2)
                #print('checksum',cksum,'\n')
                if det == 1:
                    #RFRaw.append(0)
                    #chRaw.append(ch)
                    countCal.append(count)
                    towMsCal.append(towMsR)
                    towSubMsCal.append(towSubMsR)
                    return (wnoR, towMsR, towSubMsR, timeValid)
                    #print('6')

                if det==0:
                    return[
                        (0, 1, ch, wnoR, towMsR, towSubMsR),
                        (1, 1, ch, wnoF, towMsF, towSubMsF)
                    ]
                
        return (0,0,0,0)
    
    except Exception:
        print("Error in readData")
        error_msg = (100, mac_id, 7, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        s.send(packet)
        return (0,0,0,0)
'''
def readData(det):
  global bytehdr2, slope
  try:
    print("buffer size:",uart1.any())
    findUBX_HDR()

    bytehdr2, leni = findHDR2()
    if leni > rxbuf:
        return((0,0,0,0))

    while uart1.any() < (leni+2):
        time.sleep_ms(0)
        pass
       
    if (bytehdr2 == RXM_TM):
#            print("   if RXM_TM",time.time_ns(),"ns")
            plb = uart1.read(leni)
            cksum = uart1.read(2)
            version=plb[0]
            numMeas=plb[1]
            for ii in range(0, numMeas*24, 24):
                edgeInfob=plb[8+ii:12+ii]
                edgeInfo=int.from_bytes(edgeInfob, "little")
                RF= (edgeInfo >> 4) & 1
                ch = edgeInfo & 1
                countb = plb[12+ii:14+ii]
                count=int.from_bytes(countb, "little")
                wnob=plb[14+ii:16+ii]
                wno=int.from_bytes(wnob,"little")
                towMsb=plb[16+ii:20+ii]
                towMs=int.from_bytes(towMsb,"little")
                towSubMsb=plb[20+ii:24+ii]
                towSubMs=int.from_bytes(towSubMsb,"little")
                RFRaw.append(RF)
                chRaw.append(ch)
                countRaw.append(count)
                towMsRaw.append(towMs)
                towSubMsRaw.append(towSubMs)
#            print("endif RXM_TM",time.time_ns(),"ns")

    elif (bytehdr2 == TIM_TM2):
#           print("   if TIM_TM",time.time_ns(),"ns")
            plb = uart1.read(leni)
            cksum = uart1.read(2)
            ch=plb[0]
            edgeInfo=plb[1]
            edgeF = (edgeInfo >> 2) & 1
            edgeR = (edgeInfo >> 7) & 1
            timeValid = (edgeInfo >> 6) & 1
            countb = plb[2:4]
            count=int.from_bytes(countb, "little")
            wnoRb = plb[4:6]
            wnoR=int.from_bytes(wnoRb, "little")
            wnoFb = plb[6:8]
            wnoF=int.from_bytes(wnoFb, "little")
            towMsRb=plb[8:12]
            towMsR=int.from_bytes(towMsRb,"little")
            towSubMsRb=plb[12:16]
            towSubMsR=int.from_bytes(towSubMsRb,"little")
            towMsFb=plb[16:20]
            towMsF=int.from_bytes(towMsFb,"little")
            towSubMsFb=plb[20:24]
            towSubMsF=int.from_bytes(towSubMsFb,"little")
            accEstb=plb[24:28]
            accEst=int.from_bytes(accEstb,"little")
            if det == 1:
                countCal.append(count)
                #print("*****lengths of towMsCal and towSubMsCal", len(towMsCal),len(towSubMsCal), towMsR, towSubMsR)
                towMsCal.append(towMsR)
                towSubMsCal.append(towSubMsR)
                #print("*****lengths of towMsCal and towSubMsCal", len(towMsCal),len(towSubMsCal))
                #print("endif TIM_TM",time.time_ns(),"ns")
                return (wnoR, towMsR, towSubMsR, timeValid)
            
            if det==0:
                return[
                    (0, 1, ch, wnoR, towMsR, towSubMsR),
                    (1, 1, ch, wnoF, towMsF, towSubMsF)
                ]

    elif (bytehdr2 == NAV_CLOCK):
            print("   if NAV_CK",time.time_ns(),"ns")
            plb = uart1.read(leni)
            cksum = uart1.read(2)
            iTOWb = plb[0:4]
            iTOW=int.from_bytes(iTOWb, "little")
            iclkBiasb = plb[4:8]
            iclkBias=ustruct.unpack('<i',iclkBiasb)[0]
            iclkDriftb = plb[8:12]
            iclkDrift=ustruct.unpack('<i',iclkDriftb)[0]
            tAccb = plb[12:16]
            tAcc=int.from_bytes(tAccb, "little")
            fAccb = plb[16:20]
            fAcc=int.from_bytes(fAccb, "little")
            print("      NAV_CLOCK",time.time_ns(),"ns")
            print(f"iTOW: {iTOW:d}, iclkBias: {iclkBias:d}, iclkDrift: {iclkDrift:d}, tAcc: {tAcc:d}, fAcc: {fAcc:d} ")
            slope = iclkDrift
            print('************************ slope =', slope)
            print("endif NAV_CLOCK",time.time_ns(),"ns")
    return (0,0,0,0)
    
  except Exception as e:
        print("Error in readData:",e)
        #error_msg = (100, mac_id, 5, 0, 0, 0, 0, 0, 0)
        #packet = data_packing(send_packet_format, error_msg)
        #s.send(packet)

# ---------- Info Packets ----------
error_msg = (100, mac_id, ip_last_byte, 15, time.ticks_ms(), 0, 0, 0, 0, 0) # This tells me when the board restarted how long it took to reach the main loop since booting
packet = data_packing(send_packet_format, error_msg)
send_data(packet)

time.sleep(0.1)

info_msg = (1, mac_id, ip_last_byte, 0, 0, 0, 0, 0, 0, 0) # This tells me when the board restarted how long it took to reach the main loop since booting
packet = data_packing(send_packet_format, info_msg)
send_data(packet)

# ---------- Main Loop ----------
clearRxBuf()
clear_wifi_rx_buffer()

RFRaw=[]
chRaw=[]
countRaw=[]
countCal=[]
towMsRaw=[]
towMsCal=[]
towSubMsRaw=[]
towSubMsCal=[]
uart1.write(POLL_NAV_CLOCK) #Poll Nav Clock
slope=0
tRaw1=None
tCal1 = None
Valid = 0
#initialise Valid, slope  and offset 
while ((slope == 0) or (tRaw1 == None) or (Valid == 0)):
    print('\ninit while loop', slope, tRaw1, Valid)
    uart1.write(POLL_NAV_CLOCK) #Poll Nav Clock
    for i in range(4):
        res=readData(1)
        if (res[1] > 0):
            if (res[3] > 0):
                Valid = 1
            else:
                Valid = 0
                print("GPS not locked")
                time.sleep(1)# wait 1 second before trying again
                break
        lastC=len(countCal)-1
        lastR=len(countRaw)-1
        print('countCal',countCal,'countRaw',countRaw)
    for i in range(lastR,-1,-1):
        print('line 569')
        if countRaw[i]==countCal[lastC]:
            #print("i:", i)
            print("countRaw[i]:", countRaw[i])
            print("countCal[lastC]:", countCal[lastC])
            
            tCal1=towMsCal[lastC]*1000000+(towSubMsCal[lastC])
            tRaw1=towMsRaw[i]*1000000+int(towSubMsRaw[i]/1000)
            break

clearRxBuf()

NEvents0 = 0
NEvents1 = 0
deltaT0 = 0
deltaT1 = 0
NEventsSent0=0
NEventsSent1=0
T0=time.ticks_us()

array_count = 0

while True:
    if ota_in_progress:
        print("OTA in progress: closing gps data socket")
        try:
            s.close()
            while True:
                wdt.feed()
                
        except Exception as e:
            print("Socket close error:", e)
        time.sleep(1_000_000)  # effectively idle until reset

    print("1")

    try:
        # Ensure Wi-Fi stays connected
        if not wlan.isconnected():
            print("Wi-Fi disconnected. Reconnecting...")
            con_to_wifi(ssid, password)
        
        req = recieve(20) 
        
        print("2")

        if req:
            try:
                inst, w_num, ms, sub_ms, event_num = ustruct.unpack(request_packet_format, req) #There might be an error here. What if multiple messages came in at the same time and I read them all at the same time? Will they be lost as ustruct may only evaluate the first little bit?
                print("3")
            except Exception as e:
                print("Error unpacking request:", e)
                error_msg = (100, mac_id, 8, 0, 0, 0, 0, 0, 0, 0)
                packet = data_packing(send_packet_format, error_msg)
                send_data(packet)
                continue

            if inst == 99:
                RFRaw=RFRaw[-95:]
                chRaw=chRaw[-95:]
                countRaw=countRaw[-95:]
                countCal=countCal[-2:]
                towMsRaw=towMsRaw[-95:]
                towMsCal=towMsCal[-2:]
                towSubMsRaw=towSubMsRaw[-95:]
                towSubMsCal=towSubMsCal[-2:]
                

                print("Processing GPS request...")
                print('buffer size ',uart1.any(), 'bytes\n')

                timesOfInterest = request(w_num, ms, sub_ms)
                print("4")

                if timesOfInterest is None or len(timesOfInterest)==0:
                    msg = (99, mac_id, 0, 0, 0, 0, 0, 0, event_num, array_count)

                    packet = data_packing(send_packet_format, msg)
                    send_data(packet)
                    array_count+=1
                    wdt.feed()
                    continue
                
                #print(timesOfInterest)

                print("7")
                for i in range(len(timesOfInterest)):
                    inst = 99           
                    ID = mac_id
                    RF = timesOfInterest[i][0]              
                    cal = timesOfInterest[i][1]               
                    ch = timesOfInterest[i][2]           
                    w_num = timesOfInterest[i][3]   
                    ms = timesOfInterest[i][4]      
                    sub_ms = timesOfInterest[i][5]
                    event_num = event_num 
                    count = array_count #timesOfInterest[i][6] #Useless replace with transit time
                    
                    msg = (inst, ID, RF, cal, ch, w_num, ms, sub_ms, event_num, count)

                    packet = data_packing(send_packet_format, msg)
                    print("5")
                    try:
                        
                        data = send_data(packet) #Should I start checking wifi and socket are active before sending? It seems kind of pointless,
                                        #I would have to reconnect to them anyway if it I wasnt and w
                        
                        if data:
                            array_count+=1
                            if RF==0:
                                if ch==0:
                                    NEventsSent0 +=1
                                if ch==1:
                                    NEventsSent1 +=1
                            wdt.feed()
                            print('buffer size ',uart1.any(), 'bytes\n')
                            print("data sent")
                            print("6")

                        else:
                            print("break from send data")
                            break

                    except Exception as e:
                        print("Send error:", e)
                        error_msg = (100, mac_id, 9, 0, 0, 0, 0, 0, 0, 0)
                        packet = data_packing(send_packet_format, error_msg)
                        s = reconnect_socket(s)
                        send_data(packet)

                        break  # Exit inner loop

                R0index=[]
                R1index=[]
                ##print(RFRaw)
                #print(chRaw)
                #print(towMsRaw)
                #print(len(RFRaw))
                for i in range(len(RFRaw)):
                    if RFRaw[i] == 0:
                        if chRaw[i] == 0 :
                            R0index.append(i)
                        elif chRaw[i] ==1:
                            R1index.append(i)
                length0=len(R0index)
                length1=len(R1index)
                print('length', length0,length1)
                if length0 > 0:
                    R0indexF=R0index[0]
                    R0indexL=R0index[-1]
                    print(R0index)
                    print(R0indexF, R0indexL)
                    timeElapsed0=(towMsRaw[R0indexL] - towMsRaw[R0indexF])*1000000 + int((towSubMsRaw[R0indexL] - towSubMsRaw[R0indexF])/1000)
                    print(timeElapsed0)
                    NEvents0 += length0-1
                    deltaT0 += timeElapsed0
                    print(NEvents0,deltaT0)
                if length1 > 0:
                    R1indexF=R1index[0]
                    R1indexL=R1index[-1]
                    print(R1index)
                    print(R1indexF, R1indexL)
                    print(R1indexF, R1indexL)
                    timeElapsed1=(towMsRaw[R1indexL] - towMsRaw[R1indexF])*1000000 + int((towSubMsRaw[R1indexL] - towSubMsRaw[R1indexF])/1000)
                    print(timeElapsed1)
                    NEvents1 += length1-1
                    deltaT1 += timeElapsed1
                    print(NEvents1,deltaT1)
            
                if NEvents0+ NEvents1 > 1000:
                    T1=time.ticks_us()
                    uart1.write(POLL_NAV_CLOCK)
                    Rate0 = round((NEvents0*1000000000)/(deltaT0+1e-9))
                    Rate1 = round((NEvents1*1000000000)/(deltaT1+1e-9))
                    RateSent0 = round(NEventsSent0*1000000/(T1-T0)*1000)
                    RateSent1 = round(NEventsSent1*1000000/(T1-T0)*1000)
                    print('***************************************************Rate0:',NEvents0, deltaT0,Rate0)
                    print('***************************************************Rate1:',NEvents1, deltaT1,Rate1)
                    print('***************************************************RateSent0:',NEventsSent0, T1-T0,RateSent0)
                    print('***************************************************RateSent1:',NEventsSent1, T1-T0,RateSent1)
                    NEvents0 =NEvents1=NEventsSent0=NEventsSent1=deltaT0=deltaT1=0
                    T0=T1
                                     
                    msg = (98, mac_id, Rate0, RateSent0, Rate1, RateSent1, 0, 0, 0, 0)
                    rate_packet = data_packing(send_packet_format, msg)
                    try:
                        s.send(rate_packet)
                        wdt.feed()
                        print('buffer size ',uart1.any(), 'bytes\n')

                        print("data sent")
                    except Exception as e:
                        print("error in rate calc")
                        s = reconnect_socket()
                        break  # Exit inner loop
        else:
            continue # Continue main loop if data not recieved
    except Exception as e:
        print("Main loop exception:", e)
        error_msg = (100, mac_id, 1, 0, 0, 0, 0, 0, 0, 0)
        packet = data_packing(send_packet_format, error_msg)
        send_data(packet)
        continue

        
        





