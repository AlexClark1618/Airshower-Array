import gc
import time
import array
import ustruct

def data_packing(packet_format: str, msg: tuple):
    try:
        packet = ustruct.pack(packet_format, 
            msg[0],#inst,            # char (1 byte)
            msg[1],#ID,
            msg[2],#RF,              # char (1 byte)
            msg[3],#cal,              # uint8 (1 byte)
            msg[4],#ch,          # uint8 (1 byte)
            msg[5],#w_num,      	 # uint32 (4 bytes) #Q for 8 byte uint64
            msg[6],#ms,         # uint32 (4 bytes)
            msg[7],#sub_ms,
            msg[8],#event_num                  # uint32 (4 bytes)
            msg[9] #count
        )
        
        return packet
    except Exception as e:
        print("Error in data packing", {e})
        #Cant send to server if error need data packing
#gc.collect()
#buffer = array.array('B', bytearray(5000))
#buffer_mv = memoryview(buffer)
#a = array.array('B', bytearray(200))
#a_mv = memoryview(a)
pos = 0
gc.collect()
print("Baseline:", gc.mem_free())
before = gc.mem_free()
buffer = bytearray(400)

#a = bytearray(20)
pos= 0
packet_format = "!iiiiiiiiii"
while True:
    time.sleep(0.1)
    for i in range(11):
        
        #buffer[pos: pos+len(a)] = a
        #buffer[pos: pos+len(a)] = a
        msg = (1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
        #packet = data_packing(packet_format, msg)
        #buffer += packet
        #packet = data_packing(packet_format, msg)
        print(len(buffer[:pos]))
        ustruct.pack_into(packet_format, buffer, pos, *msg)
        pos += ustruct.calcsize(packet_format)

        #pos += len(a_mv)

    pos = 0
#print("After:", gc.mem_free())
    #buffer = bytearray()
    #gc.collect()
    after =  gc.mem_free()
    print("diff:", after- before)
    #gc.collect()

