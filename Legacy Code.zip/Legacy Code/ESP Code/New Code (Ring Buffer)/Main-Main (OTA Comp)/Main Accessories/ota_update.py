import machine
import sys
import time
import gc
import os

RECV_TIMEOUT = 60
RECV_RETRIES = 10


def receive_and_install(cl, content_length, initial_data, target_file=None):
    """Receive firmware pushed via curl POST and install it.
    cl: the socket connected to curl
    content_length: expected total body size in bytes
    initial_data: body bytes already received in the first recv
    target_file: filename to install (None or "main.py" for main.py OTA)
    """
    if target_file is None or target_file == "main.py":
        temp_file = "_main_new.py"
        final_file = "main.py"
        end_marker = "# END_OF_FILE"
    else:
        temp_file = "_" + target_file + ".tmp"
        final_file = target_file
        marker_name = target_file.rsplit(".", 1)[0].upper()
        end_marker = "# END_OF_FILE_" + marker_name

    try:
        # === SEGMENT 7: SETUP ===
        print("[OTA] === SEGMENT 7: RECEIVE SETUP ===")
        gc.collect()
        print("[OTA] Free memory:", gc.mem_free())
        print("[OTA] Expecting {} bytes, got {} in initial recv".format(
            content_length, len(initial_data)))
        print("[OTA] Setting socket timeout to {}s".format(RECV_TIMEOUT))
        cl.settimeout(RECV_TIMEOUT)

        total_written = 0
        chunk_count = 0
        timeout_strikes = 0

        # === SEGMENT 8: RECEIVE DATA ===
        print("[OTA] === SEGMENT 8: RECEIVING FILE DATA ===")
        with open(temp_file, "w") as f:
            # Write the body data that came with the first recv
            if initial_data:
                f.write(initial_data.decode('utf-8'))
                total_written += len(initial_data)
                print("[OTA] Wrote {} initial bytes to temp file".format(total_written))
            else:
                print("[OTA] WARNING: No initial body data received")

            # Read remaining data from curl connection
            while total_written < content_length:
                try:
                    chunk = cl.recv(4096)
                    timeout_strikes = 0
                except OSError as e:
                    if e.args[0] == 116 and timeout_strikes < RECV_RETRIES:
                        timeout_strikes += 1
                        print("[OTA] Timeout after {}B (retry {}/{}), waiting 3s...".format(
                            total_written, timeout_strikes, RECV_RETRIES))
                        gc.collect()
                        machine.idle()
                        time.sleep(3)
                        continue
                    print("[OTA] FATAL read error after {}B: {}".format(total_written, e))
                    break

                if not chunk:
                    print("[OTA] Connection closed by curl after {}B (expected {}B)".format(
                        total_written, content_length))
                    break

                f.write(chunk.decode('utf-8'))
                total_written += len(chunk)
                chunk_count += 1

                machine.idle()
                time.sleep_ms(1)

                if chunk_count % 50 == 0:
                    gc.collect()
                    print("[OTA] Progress: {}B / {}B ({:.0f}%), free mem: {}".format(
                        total_written, content_length,
                        (total_written / content_length) * 100, gc.mem_free()))

        gc.collect()
        print("[OTA] === SEGMENT 8 COMPLETE ===")
        print("[OTA] Received: {}B / {}B expected ({:.0f}%)".format(
            total_written, content_length,
            (total_written / content_length) * 100 if content_length else 0))

        # === SEGMENT 9: VERIFY ===
        print("[OTA] === SEGMENT 9: VERIFYING END MARKER ===")
        verified = False
        with open(temp_file, "r") as f:
            try:
                f.seek(-64, 2)
            except:
                f.seek(0)
            tail = f.read()
            if end_marker in tail:
                verified = True

        if not verified:
            error_msg = "Incomplete ({}B, no {} marker)".format(total_written, end_marker)
            print("[OTA] VERIFICATION FAILED:", error_msg)
            print("[OTA] Cleaning up temp file and aborting")
            os.remove(temp_file)
            try:
                cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n")
                cl.send(b"OTA ABORTED: " + error_msg.encode() + b"\n")
                time.sleep(1)
                cl.close()
            except Exception as e:
                print("[OTA] Error sending abort response to curl:", e)
            return

        print("[OTA] VERIFICATION PASSED ({} marker found)".format(end_marker))

        # === SEGMENT 10: INSTALL ===
        print("[OTA] === SEGMENT 10: INSTALLING FIRMWARE ===")
        print("[OTA] Removing old", final_file)
        try:
            os.remove(final_file)
        except OSError:
            pass  # File may not exist yet (first push of new file)
        print("[OTA] Renaming temp file to", final_file)
        os.rename(temp_file, final_file)
        print("[OTA]", final_file, "replaced successfully. Total bytes:", total_written)

        # === SEGMENT 11: RESPOND AND REBOOT ===
        print("[OTA] === SEGMENT 11: SENDING RESPONSE TO CURL ===")
        try:
            cl.send(b"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n")
            cl.send(b"OTA complete (" + final_file.encode() + b"). Rebooting...\n")
            print("[OTA] Response sent to curl")
            time.sleep(2)
            cl.close()
            print("[OTA] Socket closed")
        except Exception as e:
            print("[OTA] Error sending success response (non-fatal):", e)

        print("[OTA] === SEGMENT 12: REBOOTING ===")
        for i in range(5):
            machine.idle()
            time.sleep(0.2)
        print("[OTA] Performing machine.reset() now")
        machine.reset()

    except Exception as e:
        print("[OTA] === UNEXPECTED ERROR ===")
        print("[OTA] Exception:", e)
        sys.print_exception(e)
        try:
            os.remove(temp_file)
            print("[OTA] Temp file cleaned up")
        except:
            print("[OTA] No temp file to clean up")
        try:
            cl.send(b"HTTP/1.1 500 Internal Server Error\r\n\r\n")
            cl.send(b"OTA failed: " + str(e).encode() + b"\n")
            time.sleep(1)
            cl.close()
        except:
            print("[OTA] Could not send error response to curl")
# END_OF_FILE_OTA_UPDATE
