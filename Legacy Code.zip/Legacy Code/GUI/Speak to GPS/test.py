import time
from machine import UART, Pin


# -----------------------------
# UART SETUP (EVK-F9T default)
# -----------------------------
uart = UART(
    1,
    baudrate=115200*4,
    bits=8,
    parity=None,
    stop=1,
    tx=Pin(12),
    rx=Pin(14),
    rxbuf=8192
)

time.sleep(0.5)   # allow GPS to boot
uart.read()       # flush any startup spam

# -----------------------------
# UBX CHECKSUM
# -----------------------------
def ubx_checksum(data):
    ck_a = 0
    ck_b = 0
    for b in data:
        ck_a = (ck_a + b) & 0xFF
        ck_b = (ck_b + ck_a) & 0xFF
    return bytes([ck_a, ck_b])

# -----------------------------
# SEND CFG-VALGET (RATE-MEAS)
# Key: 0x30210001 (U2, ms)
# -----------------------------
def send_valget_msg(key):
    #key = 0x30210001  # CFG-RATE-MEAS
    #key= 0x21ffff
    payload = (
        b'\x00'          # version
        b'\x00' 			# layers: RAM | BBR | FLASH
        b'\x00\x00'      # reserved
        + key.to_bytes(4, 'little')
    )

    msg = (
        b'\xB5\x62'                      # sync
        b'\x06\x8B'                      # CFG-VALGET
        + len(payload).to_bytes(2, 'little')
        + payload
    )

    msg += ubx_checksum(msg[2:])
    print(msg)
    uart.write(msg)
    
#key = 0x40030005

buf = []
def hex_dump(data):
    print('data:', data)
    msg= (" ".join("{:02X}".format(b) for b in data))
    print(msg)
    
    buf = msg.split(" ")
    return buf

keydict={'03002120':['E1', 'TimeRef'], '01002130':['U2', 'Rate'], '02002130':['U2', 'Nav'], '03000340':['I4', 'X'], '04000340':['I4', 'Y'], '05000340':['I4', 'Z']}

def parser():
    while uart.any():
        data = uart.read(4)
        print(data)
        
        if data == b'\xb5b\x06\x8b':
            print('ValGet header found!')
            paylen = uart.read(1)
            intlen = (int.from_bytes(paylen, "little")) 
            
            rest = (uart.read(intlen + 1 + 2))
            buf = hex_dump(rest)
            print(buf)

            payload = (buf[5:(len(buf)-2)])
            #print(payload)
            joinedpayload = ("".join(payload))
            print(joinedpayload)
            
            for key, vals in keydict.items():
                #print(key)
                #print(vals)
                if joinedpayload.find(key)!=-1:
                    keyindex= (joinedpayload.find(key))
                    if vals[0] == 'E1' or vals[0] =='U1':
                        print(vals[1],':', int((joinedpayload[keyindex+8: keyindex+10]),16))
                    if vals[0] == 'U2': 
                        print(vals[1],':', int((joinedpayload[keyindex+10: keyindex+12]+joinedpayload[keyindex+8: keyindex+10]),16))
                    if vals[0] == 'I4':
                        print(vals[1],':', int((joinedpayload[keyindex+14: keyindex+16]+joinedpayload[keyindex+12: keyindex+14]+joinedpayload[keyindex+10: keyindex+12]+joinedpayload[keyindex+8: keyindex+10]),16))

                else:
                    print('not found')
                    continue
                
            
            
        else:
            break
        
        
    
key= 0x21ffff
#key= 0x3ffff
#key = 0x30210001
send_valget_msg(key)
time.sleep(0.5)
parser()
     

