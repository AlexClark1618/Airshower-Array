from machine import UART, Pin
import time

# -----------------------------
# UART SETUP (EVK-F9T default)
# -----------------------------
uart = UART(
    1,
    baudrate=115200,
    bits=8,
    parity=None,
    stop=1,
    tx=Pin(12),
    rx=Pin(14),
    rxbuf=8192
)

time.sleep(0.5)   # allow GPS to boot
uart.read()       # flush any startup spam

# -----------------------------
# UBX CHECKSUM
# -----------------------------
def ubx_checksum(data):
    ck_a = 0
    ck_b = 0
    for b in data:
        ck_a = (ck_a + b) & 0xFF
        ck_b = (ck_b + ck_a) & 0xFF
    return bytes([ck_a, ck_b])

# -----------------------------
# SEND CFG-VALGET (RATE-MEAS)
# Key: 0x30210001 (U2, ms)
# -----------------------------
def send_valget_rate():
    key = 0x30210001  # CFG-RATE-MEAS
    #key= 0x21ffff
    payload = (
        b'\x00'          # version
        b'\x02' 			# layers: RAM | BBR | FLASH
        b'\x00\x00'      # reserved
        + key.to_bytes(4, 'little')
    )

    msg = (
        b'\xB5\x62'                      # sync
        b'\x06\x8B'                      # CFG-VALGET
        + len(payload).to_bytes(2, 'little')
        + payload
    )

    msg += ubx_checksum(msg[2:])
    print(msg)
    uart.write(msg)

# -----------------------------
# STREAMING UBX FRAME READER
# -----------------------------
def read_ubx_frame(timeout_ms=1000):
    start = time.ticks_ms()
    buf = b''

    while time.ticks_diff(time.ticks_ms(), start) < timeout_ms:
        if uart.any():
            buf += uart.read()

            while True:
                i = buf.find(b'\xB5\x62')
                if i == -1 or len(buf) < i + 6:
                    break

                length = buf[i+4] | (buf[i+5] << 8)
                frame_end = i + 6 + length + 2

                if len(buf) < frame_end:
                    break

                frame = buf[i:frame_end]
                buf = buf[frame_end:]  # consume frame
                return frame

        time.sleep_ms(10)

    return None

# -----------------------------
# WAIT FOR CFG-VALGET RESPONSE
# -----------------------------
def get_rate_meas():
    start = time.ticks_ms()

    while time.ticks_diff(time.ticks_ms(), start) < 1500:
        frame = read_ubx_frame()
        if not frame:
            continue

        cls = frame[2]
        msg_id = frame[3]

        # Only interested in CFG-VALGET
        if cls != 0x06 or msg_id != 0x8B:
            continue

        length = frame[4] | (frame[5] << 8)
        payload = frame[6:6+length]

        # payload layout:
        # U1 version
        # U1 layer
        # U2 reserved
        # U4 key
        # value...

        key = int.from_bytes(payload[4:8], 'little')
        if key != 0x30210001:
            continue

        rate_ms = int.from_bytes(payload[8:10], 'little')
        return rate_ms

    return None

# -----------------------------
# MAIN
# -----------------------------
print("Requesting measurement rate...")
send_valget_rate()

rate_ms = get_rate_meas()

if rate_ms is None:
    print("❌ Failed to read CFG-RATE-MEAS")
else:
    print("✅ Measurement rate:", rate_ms, "ms")
    print("✅ Frequency:", 1000 / rate_ms, "Hz")
