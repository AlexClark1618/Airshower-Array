from machine import UART, Pin
import time

#What should this code do and how to integrate it
    #Should have a dictionary of possible UBX messages
    #UBX msg - Header - Class - ID - Length- Payload -Checksum
    #Gives ACK or NAK
    #On GUI I will just attach specific byte msgs to the buttons, output will have to be parsed and auto fill buttons
    #Will this interfere with normal operation?
    #Send back specific values for graphing
    #I dont need to do anything too fancy. I just need to extract the number

#What msgs do I want to rx and tx
    #Survey Data *
    #CPU usage *
    #Rate *
    #Fixed or Survey *
    #TP
    #Uart1 and 2 *
    #Ver for testing *
    #SVIN TIM *
    #Reset *
    # Save Config


uart = UART(
    1,
    baudrate=115200 * 4,
    bits=8,
    parity=None,
    stop=1,
    tx=Pin(12),
    rx=Pin(14),
    rxbuf=8192
)

time.sleep(0.5)   # allow GPS to boot
uart.read() 

# UBX CHECKSUM
# -----------------------------
def ubx_checksum(data):
    ck_a = 0
    ck_b = 0
    for b in data:
        ck_a = (ck_a + b) & 0xFF
        ck_b = (ck_b + ck_a) & 0xFF
    return bytes([ck_a, ck_b])

#Note: 2 byte length entry
# SEND CFG-VALGET (RATE-MEAS)
# -----------------------------
rst_msg = msg = b'\xB5\x62\x06\x04\x04\x00\x01\00\x01\x00' # Warm start + Controlled Software reset
ver_msg = b'\xB5\x62\x0A\x04\x00\x00'
sys_msg = b'\xB5\x62\x0A\x39\x00\x00'
svin_msg = b'\xB5\x62\x0d\x04\x00\x00'

rate_dict = {"Rate": {'03002120':['E1', 'TimeRef'], '01002130':['U2', 'Rate'], '02002130':['U2', 'Nav']},
             "SurveyCart": {'01000320': ['E1', 'Mode'], '03000340':['I4', 'X'], '04000340':['I4', 'Y'], '05000340':['I4', 'Z'], '0f000340':['U4', 'ACC']},
             "SurveyAng": {'01000320': ['E1', 'Mode'], '09000340':['I4', 'LAT'], '0a000340':['I4', 'LON'], '0b000340':['I4', 'HEIGHT'], '0f000340':['U4', 'ACC']}, 
             "SurveySet": {'01000320': ['E1', 'Mode'], '10000340':['U4', 'SVIN_MIN_OBS'], '11000340':['U4', 'SVIN_ACC_LIMIT']},
             "Uart1": {'01005240': ['U4', 'Baudrate'], '02005220': ['E1', 'Stopbits'], '03005240': ['E1', 'Databits'], '04005240': ['E1', 'Parity']},
             "Uart2": {'01005340': ['U4', 'Baudrate'], '02005320': ['E1', 'Stopbits'], '03005340': ['E1', 'Databits'], '04005340': ['E1', 'Parity']},
            

             
def send_valget_msg(key):
    payload = (
        b'\x00'          # version
        b'\x00' 			# layers: RAM | BBR | FLASH #Gets it from ram
        b'\x00\x00'      # reserved
        + key.to_bytes(4, 'little')
    )

    msg = (
        b'\xB5\x62'                      # sync
        b'\x06\x8B'                      # CFG-VALGET
        + len(payload).to_bytes(2, 'little')
        + payload
    )

    msg += ubx_checksum(msg[2:])
    print(msg)
    uart.write(msg)
    
send_valget_msg(key)

time.sleep(1)

data = uart.read()

def send_valset_msg():
    key = 0x30210001              # CFG-RATE-MEAS
    value = 50 
    payload = (
        b'\x01'          # version
        b'\x05' 			# layers: RAM | BBR | FLASH
        b'\x00\x00'      # reserved
        + key.to_bytes(4, 'little')
        + value.to_bytes(2, 'little')
    )

    print(len(payload))
    msg = (
        b'\xB5\x62'                      # sync
        b'\x06\x8A'                      # CFG-VALGET
        + len(payload).to_bytes(2, 'little')
        + payload
    )

    msg += ubx_checksum(msg[2:])
    print(msg)
    uart.write(msg)


#send_valget_msg()
time.sleep(0.5)
print(uart.read())

"""
RAM only	0b001	0x01 / 1
BBR only	0b010	0x02 / 2
FLASH only	0b100	0x04 / 4
RAM + BBR	0b011	0x03 / 3
RAM + FLASH	0b101	0x05 / 5
BBR + FLASH	0b110	0x06 / 6
RAM + BBR + FLASH	0b111	0x07 / 7
"""

def hex_dump(data):
    print(" ".join("{:02X}".format(b) for b in data))

hex_dump(data)
             
buf = []
def hex_dump(data):
    print('data:', data)
    msg= (" ".join("{:02X}".format(b) for b in data))
    print(msg)
    
    buf = msg.split(" ")
    return buf

keydict={'03002120':['E1', 'TimeRef'], '01002130':['U2', 'Rate'], '02002130':['U2', 'Nav'], '03000340':['I4', 'X'], '04000340':['I4', 'Y'], '05000340':['I4', 'Z']}

def parser():
    while uart.any():
        data = uart.read(4)
        print(data)
        
        if data == b'\xb5b\x06\x8b':
            print('ValGet header found!')
            paylen = uart.read(1)
            intlen = (int.from_bytes(paylen, "little")) 
            
            rest = (uart.read(intlen + 1 + 2))
            buf = hex_dump(rest)
            print(buf)

            payload = (buf[5:(len(buf)-2)])
            #print(payload)
            joinedpayload = ("".join(payload))
            print(joinedpayload)
            
            for key, vals in keydict.items():
                #print(key)
                #print(vals)
                if joinedpayload.find(key)!=-1:
                    keyindex= (joinedpayload.find(key))
                    if vals[0] == 'E1' or vals[0] =='U1':
                        print(vals[1],':', int((joinedpayload[keyindex+8: keyindex+10]),16))
                    if vals[0] == 'U2': 
                        print(vals[1],':', int((joinedpayload[keyindex+10: keyindex+12]+joinedpayload[keyindex+8: keyindex+10]),16))
                    if vals[0] == 'I4':
                        print(vals[1],':', int((joinedpayload[keyindex+14: keyindex+16]+joinedpayload[keyindex+12: keyindex+14]+joinedpayload[keyindex+10: keyindex+12]+joinedpayload[keyindex+8: keyindex+10]),16))

                else:
                    print('not found')
                    continue
                
            
            
        else:
            break
        