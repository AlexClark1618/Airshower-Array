from machine import UART, Pin
import time

# -----------------------------
# UART SETUP (EVK-F9T default)
# -----------------------------
uart = UART(
    1,
    baudrate=115200*4,
    bits=8,
    parity=None,
    stop=1,
    tx=Pin(12),
    rx=Pin(14),
    rxbuf=8192
)

time.sleep(0.5)   # allow GPS to boot
uart.read()       # flush any startup spam

# -----------------------------
# UBX CHECKSUM
# -----------------------------
def ubx_checksum(data):
    ck_a = 0
    ck_b = 0
    for b in data:
        ck_a = (ck_a + b) & 0xFF
        ck_b = (ck_b + ck_a) & 0xFF
    return bytes([ck_a, ck_b])

# -----------------------------
# SEND CFG-VALGET (RATE-MEAS)
# Key: 0x30210001 (U2, ms)
# -----------------------------
def send_valset_msg():
    key = 0x30210001              # CFG-RATE-MEAS
    value = 50 
    payload = (
        b'\x01'          # version
        b'\x05' 			# layers: RAM | BBR | FLASH
        b'\x00\x00'      # reserved
        + key.to_bytes(4, 'little')
        + value.to_bytes(2, 'little')
    )

    print(len(payload))
    msg = (
        b'\xB5\x62'                      # sync
        b'\x06\x8A'                      # CFG-VALGET
        + len(payload).to_bytes(2, 'little')
        + payload
    )

    msg += ubx_checksum(msg[2:])
    print(msg)
    uart.write(msg)


send_valget_msg()
time.sleep(0.5)
print(uart.read())

"""
RAM only	0b001	0x01 / 1
BBR only	0b010	0x02 / 2
FLASH only	0b100	0x04 / 4
RAM + BBR	0b011	0x03 / 3
RAM + FLASH	0b101	0x05 / 5
BBR + FLASH	0b110	0x06 / 6
RAM + BBR + FLASH	0b111	0x07 / 7
"""
