import socket
import ustruct
import time
import network
from machine import UART, Pin, WDT
import time
import gc

'''
UBX_HDR = b'\xb5b'
RXM_TM=b'\x02\x74'
TIM_TM2=b'\x0d\x03'
uart1_tx_pin = 12  # Example: GPIO12
uart1_rx_pin = 14  # Example: GPIO14
rxbuf = (8192 * 3)
uart1 = UART(1, baudrate=38400, tx=Pin(uart1_tx_pin), rx=Pin(uart1_rx_pin), rxbuf= rxbuf
'''
uart = UART(
    1,
    baudrate=115200*4,
    bits=8,
    parity=None,
    stop=1,
    tx=Pin(12),
    rx=Pin(14),
    rxbuf=4096
)

def ubx_checksum(data):
    ck_a = 0
    ck_b = 0
    for b in data:
        ck_a = (ck_a + b) & 0xFF
        ck_b = (ck_b + ck_a) & 0xFF
    return bytes([ck_a, ck_b])

def ver_getter():
    msg = b'\xB5\x62\x0d\x04\x00\x00'
    
    msg += ubx_checksum(msg[2:])
    print(msg)
    #uart.read()          # flush
    uart.write(msg)
    time.sleep(1)

    data = uart.read()
    if data:
        print("RX:", data)
    return data



data = ver_getter()

buf = []
def hex_dump(data):
    print('data:', data)
    msg= (" ".join("{:02X}".format(b) for b in data))
    print(msg)
    
    buf = msg.split(" ")
    return buf

hex_dump(data)
print(buf)

#config_header = \0xB5\0x62
uart = UART(
    1,
    baudrate=38400,
    bits=8,
    parity=None,
    stop=1,
    tx=Pin(12),
    rx=Pin(14),
    rxbuf=8192
)

time.sleep(0.2)

'''
# ---- UBX CHECKSUM ----
def ubx_checksum(data):
    ck_a = 0
    ck_b = 0
    for b in data:
        ck_a = (ck_a + b) & 0xFF
        ck_b = (ck_b + ck_a) & 0xFF
    return ck_a, ck_b

# ---- CFG-VALGET for CFG-RATE-MEAS ----
# Key: 0x30210001 (U2)


payload = bytes([
    0x06, 0x8B,        # CFG-VALGET
    #0x08, 0x00,        # length
    
    0x00,              # version (request)
    0x01,              # layer = RAM
    0x00, 0x00,        # reserved
    
    0x01, 0x00, 0x21, 0x30   # CFG-RATE-MEAS
])

ck_a, ck_b = ubx_checksum(payload)
print(ck_a, ck_b)
msg = b'\xB5\x62' + payload + bytes([ck_a, ck_b])

# ---- SEND ----
print("Sending VALGET...")
uart.write(msg)

# ---- READ RAW RESPONSE ----
time.sleep(1)

raw = b''
print("Raw reply bytes:")
while uart.any():
    b = uart.read(1)
    raw+=b
    print(hex(b[0]), end=" ")

print("\nDone.")

def decode_valget(raw):
    # Find UBX header
    i = raw.find(b'\xB5\x62')
    if i == -1:
        print("No UBX header found")
        return

    cls = raw[i+2]
    msg_id = raw[i+3]

    if cls != 0x06 or msg_id != 0x8B:
        print("Not a CFG-VALGET message")
        return

    length = raw[i+4] | (raw[i+5] << 8)
    payload = raw[i+6 : i+6+length]

    # ---- Fixed header ----
    version = payload[0]
    layer   = payload[1]
    pos     = payload[2] | (payload[3] << 8)

    print("VALGET version:", version)
    print("Layer:", layer)
    print("Position:", pos)

    # ---- First key/value ----
    key = int.from_bytes(payload[4:8], 'little')

    # CFG-RATE-MEAS is U2
    value = int.from_bytes(payload[8:10], 'little')

    print("Key:", hex(key))
    print("Measurement rate (ms):", value)

decode_valget(raw)
'''

def ubx_checksum(data):
    ck_a = 0
    ck_b = 0
    for b in data:
        ck_a = (ck_a + b) & 0xFF
        ck_b = (ck_b + ck_a) & 0xFF
    return bytes([ck_a, ck_b])

# -------------------------------
# SEND CFG-VALGET (RATE-MEAS)
# -------------------------------
def send_valget_rate_meas():
    # CFG-RATE-MEAS
    #key = 0x30210001
    key = 0x21ffff
    payload = (
        b'\x00'          # version
        b'\x07'          # layer: ALL (RAM + BBR + FLASH)
        b'\x00\x00'      # reserved
        + key.to_bytes(4, 'little')
    )
    print(payload)
    msg = (
        b'\xB5\x62'                  # sync
        b'\x06\x8B'                  # CFG-VALGET
        + len(payload).to_bytes(2, 'little')
        + payload
    )
    
    print(msg)
    print(msg[2:])
    msg += ubx_checksum(msg[2:])
    print(msg)
    uart.write(msg)

time.sleep(1)

data = uart.read()
if data:
    print("RX:", data)


'''
# -------------------------------
# READ FULL UBX FRAME FROM STREAM
# -------------------------------
def read_ubx_frame(timeout_ms=500):
    start = time.ticks_ms()
    buffer = b''

    while time.ticks_diff(time.ticks_ms(), start) < timeout_ms:
        if uart.any():
            buffer += uart.read()
            # Look for UBX sync
            i = buffer.find(b'\xB5\x62')
            if i != -1 and len(buffer) >= i + 6:
                length = buffer[i+4] | (buffer[i+5] << 8)
                end = i + 6 + length + 2

                if len(buffer) >= end:
                    return buffer[i:end]

        time.sleep_ms(10)

    return None

# -------------------------------
# PARSE CFG-VALGET RESPONSE
# -------------------------------
def parse_valget_rate_meas(frame):
    if not frame:
        return None

    cls = frame[2]
    msg_id = frame[3]

    if cls != 0x06 or msg_id != 0x8B:
        return None

    length = frame[4] | (frame[5] << 8)
    payload = frame[6:6+length]

    # Skip version (1), layer (1), reserved (2)
    offset = 4

    key = int.from_bytes(payload[offset:offset+4], 'little')
    offset += 4

    if key != 0x30210001:
        return None

    rate_ms = int.from_bytes(payload[offset:offset+2], 'little')
    return rate_ms

# -------------------------------
# MAIN
# -------------------------------
uart.read()  # flush buffer

print("Requesting CFG-RATE-MEAS...")
send_valget_rate_meas()

frame = read_ubx_frame()

rate_ms = parse_valget_rate_meas(frame)

if rate_ms is None:
    print("Failed to read measurement rate")
else:
    print("Measurement rate:", rate_ms, "ms")
    print("Update frequency:", 1000 / rate_ms, "Hz")
'''

    

