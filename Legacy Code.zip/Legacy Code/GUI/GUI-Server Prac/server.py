# server.py

import socket
import time
import struct
import select
import errno

HOST = "0.0.0.0"
PORT = 12345

PACKET_FORMAT = "!iiiiiiiiii"
PACKET_SIZE = struct.calcsize(PACKET_FORMAT)

#detector_dict 
def get_socket_by_ip(client_sockets, target_ip):
    for sock in client_sockets:
        ip, port = sock.getpeername()
        if ip == target_ip:
            return sock
    return None

def start_server():
    """    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        s.setblocking(False)

        #s.settimeout(0.1)

        print(f"Server listening on {HOST}:{PORT}")

        while True:
            #time.sleep(0.1)
            try:
                conn, addr = s.accept()
                print(conn)
                print(addr[0])
            except Exception:
                continue

            with conn:
                print(f"Connected by {addr}")

                try:
                    data = conn.recv(1024)
                print(data.decode())
                inst, ID, RF, Cal, ch, w_num, ms, sub_ms, event_num, count = struct.unpack(PACKET_FORMAT, data)
                
                if not data:
                    continue
                
                #message = data.decode()
                #print("Received:", message)

                if inst == 10:
                    response = struct.pack(PACKET_FORMAT, inst, ID, RF, Cal, ch, w_num, ms, sub_ms, event_num, count )

                else:
                    pass#response = f"Server received: {message}"
                
                conn.sendall(response)
                """

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    server.setblocking(False)

    print(f"[SERVER] Server listening on {HOST}:{PORT}")

    sockets = [server]  # includes all connected sockets
    clients = {}        # map client socket -> {'buffer': bytearray, 'id': int}
    clients_ip = {}
    last_time = 0

    while True:

        if int(time.time())%60==0 and int(time.time())!=last_time: #To let you know server is running
            print(".")
            last_time = int(time.time())

        readable, _, _ = select.select(sockets, [], [], 0.1)

        for s in readable:
            print(s)
            if s is server: #Deals with server connects to client sockets
                try:
                    client_socket, addr = server.accept()
                    time.sleep(1)
                    client_socket.setblocking(False)
                    sockets.append(client_socket)
                    clients[client_socket] = { #Dictionary of client raw data and addresses
                        "buffer": bytearray(),
                        "addr": addr
                    }
                    clients_ip[addr[0]] = client_socket
                    print(f"[SERVER] New ESP32 connected from {addr}")


                except OSError as e:
                    if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        # No client to accept right now, ignore
                        continue
                    else:
                        print(f"[SERVER] Error accepting connection: {addr}; {e}")

                        continue

            else: #Reads client data
                client_info = clients.get(s)
                client_addr = client_info["addr"] if client_info else None
                try:
                    data = s.recv(1024)

                except OSError as e:
                    if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                        # Non-blocking socket has no data, this is fine
                        continue
                    else: #ETimedout isnt being used, ECONNRESET means client coneection was disconnected
                        print(f"[SERVER] Error Receiving from {client_addr}: {e}")
                        continue

                clients[s]["buffer"].extend(data)

                # Packet buffer to handle multiple packets at the same time
                while len(clients[s]["buffer"]) >= PACKET_SIZE:
                    packet = clients[s]["buffer"][:PACKET_SIZE]
                    clients[s]["buffer"] = clients[s]["buffer"][PACKET_SIZE:]

                    #Unpacks data
                    print(struct.unpack(PACKET_FORMAT, packet))
                    inst, ID, RF, Cal, ch, w_num, ms, sub_ms, event_num, count = struct.unpack(PACKET_FORMAT, packet)
                    print(list(clients.keys()))
                    if inst == 10: #GUI Code

                        if ID == 1: #Fetch Survey
                            
                            if RF == 99:

                                clients_ip['134.69.197.26'].sendall(packet)

                    if inst ==11:
                        clients_ip['134.69.237.196'].sendall(packet)
                        print("Data sent to Gui")



if __name__ == "__main__":
    print("Server Running")
    try:
        start_server()

    except KeyboardInterrupt:
        print("DAQ Stopped")