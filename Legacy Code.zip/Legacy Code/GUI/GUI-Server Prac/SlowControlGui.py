import tkinter as tk
import random as rand
import threading
import queue
import time
import socket
import struct
#from Test_Server import start_server

#stop_event = threading.Event()
#data_queue = queue.Queue()

# ---------- Socket Info -----------
HOST = "134.69.232.43"
PORT = 12345

GUI_ID = 1

PACKET_FORMAT = "!iiiiiiiiii"
PACKET_SIZE = struct.calcsize(PACKET_FORMAT)

root = tk.Tk()
root.title("GPS DAQ GUI")
root.geometry("600x400")

# ---------- Status bar ----------
status_var = tk.StringVar(value="Ready")

status_bar = tk.Label(
    root,
    textvariable=status_var,
    relief="sunken",
    anchor="w",
    padx=10
)
status_bar.pack(side="bottom", fill="x")

def data_packing(packet_format: str, msg: tuple):
    try:
        packet = struct.pack(packet_format, 
            msg[0],#inst,            # char (1 byte)
            msg[1],#ID,
            msg[2],#RF,              # char (1 byte)
            msg[3],#cal,              # uint8 (1 byte)
            msg[4],#ch,          # uint8 (1 byte)
            msg[5],#w_num,      	 # uint32 (4 bytes) #Q for 8 byte uint64
            msg[6],#ms,         # uint32 (4 bytes)
            msg[7],#sub_ms,
            msg[8],#event_num                  # uint32 (4 bytes)
            msg[9] #count
        )
        
        return packet
    except Exception as e:
        print("Error in data packing", {e})

def verify(msg):
    status_var.set(msg)

def fetch(code):
    try:
        with socket.socket() as s:
            s.connect((HOST, PORT))
            #s.sendall(b"Hello from GUI")
            if code == 1:
                msg = (10, 1, 99, 0, 0, 0, 0, 0, 0, 0)
                packet = data_packing(PACKET_FORMAT, msg)
                s.sendall(packet)
                time.sleep(1)
                #s.close()

            elif code == 2:
                s.sendall(b'2')
            else:
                print('unknown code')

            #s.connect((HOST, PORT))
            data = s.recv(1024)
            
            s.close()
            print("data receieved")
            return data
        #response_label.config(text=data.decode())

    except Exception as e:
        #response_label.config(text=f"Error: {e}")
        print("error")

def random_fill():
    msg = "Survey Coordinates Fetched"
    data = fetch(1)
    #print(struct.unpack(PACKET_FORMAT, data))
    inst, ID, RF, Cal, ch, w_num, ms, sub_ms, event_num, count = struct.unpack(PACKET_FORMAT, data)
    #print(type(data.decode()))
    verify(msg)
    #Insert random integers into get survey entry boxes
    if x_survey_entry.get() or y_survey_entry.get() or z_survey_entry.get() or acc_survey_entry.get():
        x_survey_entry.delete(0, tk.END)
        y_survey_entry.delete(0, tk.END)
        z_survey_entry.delete(0, tk.END)
        acc_survey_entry.delete(0, tk.END)

    x_survey_entry.insert(tk.END, w_num)#rand.randint(1,9))
    y_survey_entry.insert(tk.END, ms) ##rand.randint(1,9))
    z_survey_entry.insert(tk.END, sub_ms) #rand.randint(1,9))
    acc_survey_entry.insert(tk.END, 0)#rand.randint(1,9))

def send_fix_coordinates():
    msg = "Fixed Coordinates Sent"
    verify(msg)
    #This function will send fixed coordinates to gps
    pass
"""
def start_run():
    global t
    msg = "Run Started"
    verify(msg)

    stop_event.clear()

    t = threading.Thread(target=start_server,  args=(data_queue, stop_event), daemon=True)
    t.start()

def end_run():

    stop_event.set()  # stops thread cleanly
    t.join()

    msg = "Run Ended"
    verify(msg)
"""
# Main container
container = tk.Frame(root)
container.pack(fill="both", expand=True)

# Two columns
left = tk.Frame(container)
right = tk.Frame(container)

left.grid(row=0, column=0, sticky="nsew", padx=10)
right.grid(row=0, column=1, sticky="nsew", padx=10)

# Allow resizing
container.columnconfigure(0, weight=1)
container.columnconfigure(1, weight=1)

"""# Populate left
daq_label = tk.Label(left, text="DAQ Controls", font=("Arial", 14))
daq_label.grid(row=0, column=0, sticky="w")
tk.Button(left, text="Start Run", command = start_run).grid(row=1, column=0, sticky="w")
tk.Button(left, text="End Run", command = end_run).grid(row=2, column=0, sticky="w")"""

# Populate right
gps_label = tk.Label(right, text="GPS Controls", font=("Arial", 14))
gps_label.grid(row=0, column=0, sticky="w")

OPTIONS = [
    "BH",
    "Veto",
    "Det 1",
    "Det 2",
    "Det 3",
    "Det 4",
    "Det 5",
    "Det 6",
    "Det 7",
    "Det 8",
    "Det 9",
    "Det 10"
] # Define the list of choices

# Create a Tkinter variable and set the default option
variable = tk.StringVar(root)
variable.set(OPTIONS[0]) # Default value

# Create the OptionMenu widget
dropdown_menu = tk.OptionMenu(right, variable, *OPTIONS)
dropdown_menu.grid(row=1, column=0, pady = 5, sticky="w")

tk.Button(right, text="Start Survey", command = lambda: verify('Survey Started')).grid(row=2, column=0, pady = 5, sticky="w")

tk.Button(right, text="Get Survey Results", command = random_fill).grid(row=3, column=0, pady = 5, sticky="w")

#X Variable#
x_cell = tk.Frame(right)
x_cell.grid(row=4, column=0, sticky="w")

x_survey_label = tk.Label(x_cell, text="x:")
x_survey_label.pack(side="left")

x_survey_entry = tk.Entry(x_cell, width=18, text="x:") #Text attribute in entries doesnt do what I expected
x_survey_entry.pack(side="left")

#Y Variable#
y_cell = tk.Frame(right)
y_cell.grid(row=5, column=0, sticky="w")

y_survey_label = tk.Label(y_cell, text="y:")
y_survey_label.pack(side="left")

y_survey_entry = tk.Entry(y_cell, width=18, text="y:") #Text attribute in entries doesnt do what I expected
y_survey_entry.pack(side="left")

#X Variable#
z_cell = tk.Frame(right)
z_cell.grid(row=6, column=0, sticky="w")

z_survey_label = tk.Label(z_cell, text="z:")
z_survey_label.pack(side="left")

z_survey_entry = tk.Entry(z_cell, width=18, text="z:") #Text attribute in entries doesnt do what I expected
z_survey_entry.pack(side="left")

#ACC Variable#
acc_cell = tk.Frame(right)
acc_cell.grid(row=7, column=0, sticky="w")

acc_survey_label = tk.Label(acc_cell, text="Acc:")
acc_survey_label.pack(side="left")

acc_survey_entry = tk.Entry(acc_cell, width=15, text="Acc:") #Text attribute in entries doesnt do what I expected
acc_survey_entry.pack(side="left")

###Observastion Time###
###Survey Status###
###Survey Time length###
###Positional Accuracy###

tk.Button(right, text="Fix Coordinates", command = send_fix_coordinates).grid(row=8, column=0, pady = 5, sticky='w')
#X Variable#
x_cell = tk.Frame(right)
x_cell.grid(row=9, column=0, sticky="w")

x_survey_label = tk.Label(x_cell, text="x:")
x_survey_label.pack(side="left")

x_survey_entry = tk.Entry(x_cell, width=18, text="x:") #Text attribute in entries doesnt do what I expected
x_survey_entry.pack(side="left")

#Y Variable#
y_cell = tk.Frame(right)
y_cell.grid(row=10, column=0, sticky="w")

y_survey_label = tk.Label(y_cell, text="y:")
y_survey_label.pack(side="left")

y_survey_entry = tk.Entry(y_cell, width=18, text="y:") #Text attribute in entries doesnt do what I expected
y_survey_entry.pack(side="left")

#X Variable#
z_cell = tk.Frame(right)
z_cell.grid(row=11, column=0, sticky="w")

z_survey_label = tk.Label(z_cell, text="z:")
z_survey_label.pack(side="left")

z_survey_entry = tk.Entry(z_cell, width=18, text="z:") #Text attribute in entries doesnt do what I expected
z_survey_entry.pack(side="left")

#ACC Variable#
acc_cell = tk.Frame(right)
acc_cell.grid(row=12, column=0, sticky="w")

acc_survey_label = tk.Label(acc_cell, text="Acc:")
acc_survey_label.pack(side="left")

acc_survey_entry = tk.Entry(acc_cell, width=15, text="Acc:") #Text attribute in entries doesnt do what I expected
acc_survey_entry.pack(side="left")


root.mainloop()