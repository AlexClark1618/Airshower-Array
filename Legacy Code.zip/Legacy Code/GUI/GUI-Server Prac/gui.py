# gui.py

import socket
import tkinter as tk

HOST = "134.69.237.196"
PORT = 12345

def send_message():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((HOST, PORT))
            s.sendall(b"Hello from GUI")

            data = s.recv(1024)

        response_label.config(text=data.decode())

    except Exception as e:
        response_label.config(text=f"Error: {e}")

# Create GUI
root = tk.Tk()
root.title("Simple TCP Client")

send_button = tk.Button(root, text="Send Message", command=send_message)
send_button.pack(pady=10)

response_label = tk.Label(root, text="Server response will appear here")
response_label.pack(pady=10)

root.mainloop()